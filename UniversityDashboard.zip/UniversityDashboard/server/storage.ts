import { 
  users, User, InsertUser, 
  courses, Course, InsertCourse,
  assignments, Assignment, InsertAssignment,
  studentAssignments, StudentAssignment, InsertStudentAssignment,
  announcements, Announcement, InsertAnnouncement,
  attendance, Attendance, InsertAttendance,
  grades, Grade, InsertGrade
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUsersByRole(role: string): Promise<User[]>;
  authenticateUser(username: string, password: string, role: string): Promise<User | undefined>;

  // Course operations
  getCourse(id: number): Promise<Course | undefined>;
  getCourses(): Promise<Course[]>;
  getCoursesByDepartment(department: string): Promise<Course[]>;
  createCourse(course: InsertCourse): Promise<Course>;

  // Assignment operations
  getAssignment(id: number): Promise<Assignment | undefined>;
  getAssignmentsByCourse(courseId: number): Promise<Assignment[]>;
  getAssignmentsByFaculty(facultyId: number): Promise<Assignment[]>;
  createAssignment(assignment: InsertAssignment): Promise<Assignment>;
  updateAssignment(id: number, data: Partial<Assignment>): Promise<Assignment | undefined>;

  // Student assignment operations
  getStudentAssignment(id: number): Promise<StudentAssignment | undefined>;
  getStudentAssignmentsByStudent(studentId: number): Promise<StudentAssignment[]>;
  getStudentAssignmentsByAssignment(assignmentId: number): Promise<StudentAssignment[]>;
  createStudentAssignment(studentAssignment: InsertStudentAssignment): Promise<StudentAssignment>;
  updateStudentAssignment(id: number, data: Partial<StudentAssignment>): Promise<StudentAssignment | undefined>;

  // Announcement operations
  getAnnouncement(id: number): Promise<Announcement | undefined>;
  getAnnouncements(): Promise<Announcement[]>;
  getAnnouncementsByDepartment(department: string): Promise<Announcement[]>;
  createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement>;

  // Attendance operations
  getAttendance(id: number): Promise<Attendance | undefined>;
  getAttendanceByStudent(studentId: number): Promise<Attendance[]>;
  getAttendanceByStudentAndCourse(studentId: number, courseId: number): Promise<Attendance[]>;
  createAttendance(attendance: InsertAttendance): Promise<Attendance>;
  getAttendanceByCourse(courseId: number): Promise<Attendance[]>;

  // Grade operations
  getGrade(id: number): Promise<Grade | undefined>;
  getGradesByStudent(studentId: number): Promise<Grade[]>;
  getGradesByCourse(courseId: number): Promise<Grade[]>;
  createGrade(grade: InsertGrade): Promise<Grade>;
  updateGrade(id: number, data: Partial<Grade>): Promise<Grade | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private courses: Map<number, Course>;
  private assignments: Map<number, Assignment>;
  private studentAssignments: Map<number, StudentAssignment>;
  private announcements: Map<number, Announcement>;
  private attendanceRecords: Map<number, Attendance>;
  private grades: Map<number, Grade>;
  
  private userCurrentId: number;
  private courseCurrentId: number;
  private assignmentCurrentId: number;
  private studentAssignmentCurrentId: number;
  private announcementCurrentId: number;
  private attendanceCurrentId: number;
  private gradeCurrentId: number;

  constructor() {
    this.users = new Map();
    this.courses = new Map();
    this.assignments = new Map();
    this.studentAssignments = new Map();
    this.announcements = new Map();
    this.attendanceRecords = new Map();
    this.grades = new Map();
    
    this.userCurrentId = 1;
    this.courseCurrentId = 1;
    this.assignmentCurrentId = 1;
    this.studentAssignmentCurrentId = 1;
    this.announcementCurrentId = 1;
    this.attendanceCurrentId = 1;
    this.gradeCurrentId = 1;
    
    // Initialize with demo data
    this.initDemoData();
  }

  // Initialize demo data
  private async initDemoData() {
    // Add sample users
    await this.createUser({
      username: "student",
      password: "password",
      firstName: "John",
      lastName: "Doe",
      email: "john.doe@university.edu",
      role: "student",
      department: "Computer Science",
      program: "Computer Science",
      semester: 5,
      profileImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
    });

    await this.createUser({
      username: "faculty",
      password: "password",
      firstName: "Dr. Robert",
      lastName: "Johnson",
      email: "robert.johnson@university.edu",
      role: "faculty",
      department: "Computer Science",
      profileImage: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
    });

    await this.createUser({
      username: "admin",
      password: "password",
      firstName: "Admin",
      lastName: "User",
      email: "admin@university.edu",
      role: "admin",
      profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
    });

    // Add sample courses
    const dbCourse = await this.createCourse({
      code: "CSE-301",
      name: "Database Systems",
      description: "Introduction to database systems concepts and architecture",
      department: "Computer Science",
      credits: 4,
      type: "theory"
    });

    const algCourse = await this.createCourse({
      code: "CSE-302",
      name: "Algorithms",
      description: "Analysis and design of algorithms",
      department: "Computer Science",
      credits: 4,
      type: "theory"
    });

    const webCourse = await this.createCourse({
      code: "CSE-303",
      name: "Web Development",
      description: "Web application development using modern frameworks",
      department: "Computer Science",
      credits: 3,
      type: "theory"
    });

    const dbLabCourse = await this.createCourse({
      code: "CSE-301L",
      name: "Database Lab",
      description: "Practical implementation of database concepts",
      department: "Computer Science",
      credits: 2,
      type: "lab"
    });

    // Add sample announcements
    await this.createAnnouncement({
      title: "Mid-term Examination Schedule",
      content: "The mid-term examinations will begin from 15th October. Check the schedule for details.",
      createdBy: 2, // Faculty ID
      department: "Computer Science",
      createdAt: new Date()
    });

    await this.createAnnouncement({
      title: "Campus Network Maintenance",
      content: "Network maintenance scheduled on 8th October from 2-4 PM. Internet services may be disrupted.",
      createdBy: 3, // Admin ID
      createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000) // 1 day ago
    });

    // Add sample assignments
    const dbAssignment = await this.createAssignment({
      title: "Database Normalization",
      description: "Convert the given schema to 3NF and implement in SQL",
      courseId: dbCourse.id,
      dueDate: new Date(Date.now() + 24 * 60 * 60 * 1000), // Due tomorrow
      maxMarks: 20,
      assignmentType: "theory",
      createdBy: 2, // Faculty ID
      isChecked: false
    });

    const algAssignment = await this.createAssignment({
      title: "Algorithm Implementation",
      description: "Implement heap sort and analyze its time complexity",
      courseId: algCourse.id,
      dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // Due in 3 days
      maxMarks: 25,
      assignmentType: "lab",
      createdBy: 2,
      isChecked: false
    });

    // Add sample student assignments
    await this.createStudentAssignment({
      studentId: 1, // Student ID
      assignmentId: dbAssignment.id,
      status: "pending"
    });

    await this.createStudentAssignment({
      studentId: 1,
      assignmentId: algAssignment.id,
      status: "pending"
    });

    // Add sample attendance for student
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const twoDaysAgo = new Date(today);
    twoDaysAgo.setDate(twoDaysAgo.getDate() - 2);

    await this.createAttendance({
      studentId: 1,
      courseId: dbCourse.id,
      date: today,
      status: true,
      notes: ""
    });

    await this.createAttendance({
      studentId: 1,
      courseId: algCourse.id,
      date: today,
      status: true,
      notes: ""
    });

    await this.createAttendance({
      studentId: 1,
      courseId: webCourse.id,
      date: today,
      status: true,
      notes: ""
    });

    await this.createAttendance({
      studentId: 1,
      courseId: dbCourse.id,
      date: yesterday,
      status: true,
      notes: ""
    });

    await this.createAttendance({
      studentId: 1,
      courseId: algCourse.id,
      date: yesterday,
      status: false,
      notes: "Student was sick"
    });

    await this.createAttendance({
      studentId: 1,
      courseId: webCourse.id,
      date: yesterday,
      status: true,
      notes: ""
    });

    await this.createAttendance({
      studentId: 1,
      courseId: dbCourse.id,
      date: twoDaysAgo,
      status: true,
      notes: ""
    });

    await this.createAttendance({
      studentId: 1,
      courseId: algCourse.id,
      date: twoDaysAgo,
      status: true,
      notes: ""
    });

    await this.createAttendance({
      studentId: 1,
      courseId: webCourse.id,
      date: twoDaysAgo,
      status: true,
      notes: ""
    });

    // Add sample grades for student
    await this.createGrade({
      studentId: 1,
      courseId: dbCourse.id,
      internalMarks: 18, // out of 20
      midtermMarks: 28, // out of 30
      assignmentMarks: 22, // out of 25
      finalMarks: null, // Upcoming
      totalMarks: null,
      grade: "A",
      term: "Fall 2023"
    });

    await this.createGrade({
      studentId: 1,
      courseId: algCourse.id,
      internalMarks: 16, // out of 20
      midtermMarks: 24, // out of 30
      assignmentMarks: 20, // out of 25
      finalMarks: null, // Upcoming
      totalMarks: null,
      grade: "B+",
      term: "Fall 2023"
    });

    await this.createGrade({
      studentId: 1,
      courseId: webCourse.id,
      internalMarks: 19, // out of 20
      midtermMarks: 27, // out of 30
      assignmentMarks: 24, // out of 25
      finalMarks: null, // Upcoming
      totalMarks: null,
      grade: "A",
      term: "Fall 2023"
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const newUser: User = { ...user, id };
    this.users.set(id, newUser);
    return newUser;
  }

  async getUsersByRole(role: string): Promise<User[]> {
    return Array.from(this.users.values()).filter(
      (user) => user.role === role
    );
  }

  async authenticateUser(username: string, password: string, role: string): Promise<User | undefined> {
    const user = await this.getUserByUsername(username);
    if (user && user.password === password && user.role === role) {
      return user;
    }
    return undefined;
  }

  // Course operations
  async getCourse(id: number): Promise<Course | undefined> {
    return this.courses.get(id);
  }

  async getCourses(): Promise<Course[]> {
    return Array.from(this.courses.values());
  }

  async getCoursesByDepartment(department: string): Promise<Course[]> {
    return Array.from(this.courses.values()).filter(
      (course) => course.department === department
    );
  }

  async createCourse(course: InsertCourse): Promise<Course> {
    const id = this.courseCurrentId++;
    const newCourse: Course = { ...course, id };
    this.courses.set(id, newCourse);
    return newCourse;
  }

  // Assignment operations
  async getAssignment(id: number): Promise<Assignment | undefined> {
    return this.assignments.get(id);
  }

  async getAssignmentsByCourse(courseId: number): Promise<Assignment[]> {
    return Array.from(this.assignments.values()).filter(
      (assignment) => assignment.courseId === courseId
    );
  }

  async getAssignmentsByFaculty(facultyId: number): Promise<Assignment[]> {
    return Array.from(this.assignments.values()).filter(
      (assignment) => assignment.createdBy === facultyId
    );
  }

  async createAssignment(assignment: InsertAssignment): Promise<Assignment> {
    const id = this.assignmentCurrentId++;
    const newAssignment: Assignment = { ...assignment, id };
    this.assignments.set(id, newAssignment);
    return newAssignment;
  }

  async updateAssignment(id: number, data: Partial<Assignment>): Promise<Assignment | undefined> {
    const assignment = await this.getAssignment(id);
    if (!assignment) return undefined;

    const updatedAssignment = { ...assignment, ...data };
    this.assignments.set(id, updatedAssignment);
    return updatedAssignment;
  }

  // Student assignment operations
  async getStudentAssignment(id: number): Promise<StudentAssignment | undefined> {
    return this.studentAssignments.get(id);
  }

  async getStudentAssignmentsByStudent(studentId: number): Promise<StudentAssignment[]> {
    return Array.from(this.studentAssignments.values()).filter(
      (studentAssignment) => studentAssignment.studentId === studentId
    );
  }

  async getStudentAssignmentsByAssignment(assignmentId: number): Promise<StudentAssignment[]> {
    return Array.from(this.studentAssignments.values()).filter(
      (studentAssignment) => studentAssignment.assignmentId === assignmentId
    );
  }

  async createStudentAssignment(studentAssignment: InsertStudentAssignment): Promise<StudentAssignment> {
    const id = this.studentAssignmentCurrentId++;
    const newStudentAssignment: StudentAssignment = { ...studentAssignment, id };
    this.studentAssignments.set(id, newStudentAssignment);
    return newStudentAssignment;
  }

  async updateStudentAssignment(id: number, data: Partial<StudentAssignment>): Promise<StudentAssignment | undefined> {
    const studentAssignment = await this.getStudentAssignment(id);
    if (!studentAssignment) return undefined;

    const updatedStudentAssignment = { ...studentAssignment, ...data };
    this.studentAssignments.set(id, updatedStudentAssignment);
    return updatedStudentAssignment;
  }

  // Announcement operations
  async getAnnouncement(id: number): Promise<Announcement | undefined> {
    return this.announcements.get(id);
  }

  async getAnnouncements(): Promise<Announcement[]> {
    return Array.from(this.announcements.values()).sort((a, b) => {
      if (!a.createdAt || !b.createdAt) return 0;
      return b.createdAt.getTime() - a.createdAt.getTime();
    });
  }

  async getAnnouncementsByDepartment(department: string): Promise<Announcement[]> {
    return Array.from(this.announcements.values())
      .filter((announcement) => !announcement.department || announcement.department === department)
      .sort((a, b) => {
        if (!a.createdAt || !b.createdAt) return 0;
        return b.createdAt.getTime() - a.createdAt.getTime();
      });
  }

  async createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement> {
    const id = this.announcementCurrentId++;
    const newAnnouncement: Announcement = { ...announcement, id };
    this.announcements.set(id, newAnnouncement);
    return newAnnouncement;
  }

  // Attendance operations
  async getAttendance(id: number): Promise<Attendance | undefined> {
    return this.attendanceRecords.get(id);
  }

  async getAttendanceByStudent(studentId: number): Promise<Attendance[]> {
    return Array.from(this.attendanceRecords.values()).filter(
      (attendance) => attendance.studentId === studentId
    );
  }

  async getAttendanceByStudentAndCourse(studentId: number, courseId: number): Promise<Attendance[]> {
    return Array.from(this.attendanceRecords.values()).filter(
      (attendance) => attendance.studentId === studentId && attendance.courseId === courseId
    );
  }

  async createAttendance(attendance: InsertAttendance): Promise<Attendance> {
    const id = this.attendanceCurrentId++;
    const newAttendance: Attendance = { ...attendance, id };
    this.attendanceRecords.set(id, newAttendance);
    return newAttendance;
  }

  async getAttendanceByCourse(courseId: number): Promise<Attendance[]> {
    return Array.from(this.attendanceRecords.values()).filter(
      (attendance) => attendance.courseId === courseId
    );
  }

  // Grade operations
  async getGrade(id: number): Promise<Grade | undefined> {
    return this.grades.get(id);
  }

  async getGradesByStudent(studentId: number): Promise<Grade[]> {
    return Array.from(this.grades.values()).filter(
      (grade) => grade.studentId === studentId
    );
  }

  async getGradesByCourse(courseId: number): Promise<Grade[]> {
    return Array.from(this.grades.values()).filter(
      (grade) => grade.courseId === courseId
    );
  }

  async createGrade(grade: InsertGrade): Promise<Grade> {
    const id = this.gradeCurrentId++;
    const newGrade: Grade = { ...grade, id };
    this.grades.set(id, newGrade);
    return newGrade;
  }

  async updateGrade(id: number, data: Partial<Grade>): Promise<Grade | undefined> {
    const grade = await this.getGrade(id);
    if (!grade) return undefined;

    const updatedGrade = { ...grade, ...data };
    this.grades.set(id, updatedGrade);
    return updatedGrade;
  }
}

export const storage = new MemStorage();
