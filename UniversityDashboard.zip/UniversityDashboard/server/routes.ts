import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import session from "express-session";
import { loginSchema } from "@shared/schema";
import { z } from "zod";

declare module "express-session" {
  interface SessionData {
    userId: number;
    role: string;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup session middleware
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "university-management-secret",
      resave: false,
      saveUninitialized: false,
      cookie: { secure: process.env.NODE_ENV === "production" }
    })
  );

  // Authentication routes
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const credentials = loginSchema.parse(req.body);
      const user = await storage.authenticateUser(
        credentials.username,
        credentials.password,
        credentials.role
      );

      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Store user info in session
      req.session.userId = user.id;
      req.session.role = user.role;

      // Return user without password
      const { password, ...userWithoutPassword } = user;
      return res.status(200).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/auth/me", async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const user = await storage.getUser(req.session.userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Return user without password
    const { password, ...userWithoutPassword } = user;
    return res.status(200).json(userWithoutPassword);
  });

  app.post("/api/auth/logout", (req: Request, res: Response) => {
    req.session.destroy(err => {
      if (err) {
        return res.status(500).json({ message: "Server error" });
      }
      return res.status(200).json({ message: "Logged out successfully" });
    });
  });

  // Middleware to check authentication
  const isAuthenticated = (req: Request, res: Response, next: Function) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    next();
  };

  // Middleware to check role
  const hasRole = (roles: string[]) => {
    return (req: Request, res: Response, next: Function) => {
      if (!req.session.role || !roles.includes(req.session.role)) {
        return res.status(403).json({ message: "Access denied" });
      }
      next();
    };
  };

  // User routes
  app.get("/api/users", isAuthenticated, hasRole(["admin"]), async (req: Request, res: Response) => {
    try {
      const role = req.query.role as string;
      const users = role ? await storage.getUsersByRole(role) : await storage.getUsersByRole("student");
      
      // Remove passwords from response
      const usersWithoutPasswords = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      
      return res.status(200).json(usersWithoutPasswords);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Course routes
  app.get("/api/courses", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const department = req.query.department as string;
      const courses = department 
        ? await storage.getCoursesByDepartment(department) 
        : await storage.getCourses();
      
      return res.status(200).json(courses);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Announcement routes
  app.get("/api/announcements", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const department = req.query.department as string;
      const announcements = department 
        ? await storage.getAnnouncementsByDepartment(department) 
        : await storage.getAnnouncements();
      
      return res.status(200).json(announcements);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/announcements", isAuthenticated, hasRole(["faculty", "admin"]), async (req: Request, res: Response) => {
    try {
      const announcementData = {
        ...req.body,
        createdBy: req.session.userId,
        createdAt: new Date()
      };
      
      const announcement = await storage.createAnnouncement(announcementData);
      return res.status(201).json(announcement);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Assignment routes
  app.get("/api/assignments", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const courseId = parseInt(req.query.courseId as string);
      const facultyId = parseInt(req.query.facultyId as string);
      
      let assignments = [];
      if (courseId) {
        assignments = await storage.getAssignmentsByCourse(courseId);
      } else if (facultyId) {
        assignments = await storage.getAssignmentsByFaculty(facultyId);
      } else {
        return res.status(400).json({ message: "Missing query parameter: courseId or facultyId" });
      }
      
      return res.status(200).json(assignments);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/assignments", isAuthenticated, hasRole(["faculty"]), async (req: Request, res: Response) => {
    try {
      const assignmentData = {
        ...req.body,
        createdBy: req.session.userId
      };
      
      const assignment = await storage.createAssignment(assignmentData);
      return res.status(201).json(assignment);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/assignments/:id", isAuthenticated, hasRole(["faculty"]), async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const assignment = await storage.getAssignment(id);
      
      if (!assignment) {
        return res.status(404).json({ message: "Assignment not found" });
      }
      
      if (assignment.createdBy !== req.session.userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const updatedAssignment = await storage.updateAssignment(id, req.body);
      return res.status(200).json(updatedAssignment);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Student assignment routes
  app.get("/api/student-assignments", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const studentId = parseInt(req.query.studentId as string);
      const assignmentId = parseInt(req.query.assignmentId as string);
      
      let studentAssignments = [];
      if (studentId) {
        studentAssignments = await storage.getStudentAssignmentsByStudent(studentId);
      } else if (assignmentId) {
        studentAssignments = await storage.getStudentAssignmentsByAssignment(assignmentId);
      } else {
        return res.status(400).json({ message: "Missing query parameter: studentId or assignmentId" });
      }
      
      return res.status(200).json(studentAssignments);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/student-assignments", isAuthenticated, hasRole(["student"]), async (req: Request, res: Response) => {
    try {
      const studentAssignmentData = {
        ...req.body,
        studentId: req.session.userId,
        submissionDate: new Date(),
        status: "submitted"
      };
      
      const studentAssignment = await storage.createStudentAssignment(studentAssignmentData);
      return res.status(201).json(studentAssignment);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/student-assignments/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const studentAssignment = await storage.getStudentAssignment(id);
      
      if (!studentAssignment) {
        return res.status(404).json({ message: "Student assignment not found" });
      }
      
      if (req.session.role === "student" && studentAssignment.studentId !== req.session.userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const updatedStudentAssignment = await storage.updateStudentAssignment(id, req.body);
      return res.status(200).json(updatedStudentAssignment);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Attendance routes
  app.get("/api/attendance", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const studentId = parseInt(req.query.studentId as string);
      const courseId = parseInt(req.query.courseId as string);
      
      let attendanceRecords = [];
      if (studentId && courseId) {
        attendanceRecords = await storage.getAttendanceByStudentAndCourse(studentId, courseId);
      } else if (studentId) {
        attendanceRecords = await storage.getAttendanceByStudent(studentId);
      } else if (courseId) {
        attendanceRecords = await storage.getAttendanceByCourse(courseId);
      } else {
        return res.status(400).json({ message: "Missing query parameter: studentId or courseId" });
      }
      
      return res.status(200).json(attendanceRecords);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/attendance", isAuthenticated, hasRole(["faculty"]), async (req: Request, res: Response) => {
    try {
      const attendance = await storage.createAttendance(req.body);
      return res.status(201).json(attendance);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Grade routes
  app.get("/api/grades", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const studentId = parseInt(req.query.studentId as string);
      const courseId = parseInt(req.query.courseId as string);
      
      let grades = [];
      if (studentId) {
        grades = await storage.getGradesByStudent(studentId);
      } else if (courseId) {
        grades = await storage.getGradesByCourse(courseId);
      } else {
        return res.status(400).json({ message: "Missing query parameter: studentId or courseId" });
      }
      
      return res.status(200).json(grades);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/grades", isAuthenticated, hasRole(["faculty"]), async (req: Request, res: Response) => {
    try {
      const grade = await storage.createGrade(req.body);
      return res.status(201).json(grade);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/grades/:id", isAuthenticated, hasRole(["faculty"]), async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const grade = await storage.getGrade(id);
      
      if (!grade) {
        return res.status(404).json({ message: "Grade not found" });
      }
      
      const updatedGrade = await storage.updateGrade(id, req.body);
      return res.status(200).json(updatedGrade);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
