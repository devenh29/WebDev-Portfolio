import React from 'react';
import { Link } from 'wouter';
import { motion } from 'framer-motion';

import { Button } from '@/components/ui/button';

const Home: React.FC = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-500 to-blue-600 flex items-center justify-center p-4">
      <motion.div 
        className="max-w-4xl w-full text-white text-center"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.h1 
          className="text-4xl md:text-6xl font-bold mb-6 font-heading"
          variants={itemVariants}
        >
          University Management System
        </motion.h1>
        
        <motion.p 
          className="text-lg md:text-xl mb-12 max-w-3xl mx-auto opacity-90"
          variants={itemVariants}
        >
          A modern platform for students, faculty, and administrators to manage academic activities efficiently
        </motion.p>
        
        <motion.div 
          className="flex flex-col sm:flex-row gap-4 justify-center"
          variants={itemVariants}
        >
          <Button 
            asChild
            className="bg-white text-indigo-700 hover:bg-indigo-100 px-8 py-3 text-lg rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
          >
            <Link href="/login">
              Get Started
            </Link>
          </Button>
          
          <Button 
            asChild
            variant="outline"
            className="border-2 border-white bg-transparent text-white hover:bg-white/20 px-8 py-3 text-lg rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
          >
            <a href="https://github.com" target="_blank" rel="noopener noreferrer">
              Learn More
            </a>
          </Button>
        </motion.div>
        
        <motion.div 
          className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 text-center"
          variants={containerVariants}
        >
          <motion.div 
            className="bg-white/10 backdrop-blur-sm p-6 rounded-xl shadow-lg"
            variants={itemVariants}
            whileHover={{ y: -5, transition: { duration: 0.2 } }}
          >
            <div className="bg-indigo-700/30 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-2">Student Portal</h3>
            <p className="text-white/80">Access assignments, check grades, and track attendance all in one place</p>
          </motion.div>
          
          <motion.div 
            className="bg-white/10 backdrop-blur-sm p-6 rounded-xl shadow-lg"
            variants={itemVariants}
            whileHover={{ y: -5, transition: { duration: 0.2 } }}
          >
            <div className="bg-indigo-700/30 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-2">Faculty Dashboard</h3>
            <p className="text-white/80">Manage assignments, attendance tracking, and grade submissions efficiently</p>
          </motion.div>
          
          <motion.div 
            className="bg-white/10 backdrop-blur-sm p-6 rounded-xl shadow-lg"
            variants={itemVariants}
            whileHover={{ y: -5, transition: { duration: 0.2 } }}
          >
            <div className="bg-indigo-700/30 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-2">Admin Control</h3>
            <p className="text-white/80">Comprehensive tools for university management and system administration</p>
          </motion.div>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default Home;
