import React, { useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { motion } from 'framer-motion';

import Navbar from '@/components/layout/Navbar';
import Sidebar from '@/components/layout/Sidebar';
import StudentDashboard from '@/components/dashboards/StudentDashboard';
import FacultyDashboard from '@/components/dashboards/FacultyDashboard';
import AdminDashboard from '@/components/dashboards/AdminDashboard';
import { useToast } from '@/hooks/use-toast';
import { User } from '@shared/schema';

const Dashboard: React.FC = () => {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();

  // Fetch current user
  const { data: user, isLoading, error } = useQuery<User>({
    queryKey: ['/api/auth/me'],
    retry: false,
  });

  useEffect(() => {
    if (error) {
      toast({
        title: "Authentication Error",
        description: "Please log in to access this page",
        variant: "destructive",
      });
      setLocation('/login');
    }
  }, [error, setLocation, toast]);

  const handleLogout = () => {
    setLocation('/login');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center"
        >
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-indigo-600 border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
          <p className="mt-4 text-slate-600">Loading your dashboard...</p>
        </motion.div>
      </div>
    );
  }

  if (!user) {
    return null; // Will redirect in useEffect
  }

  // Need to assert user as User type to help TypeScript
  const typedUser = user as User;

  // Render dashboards without sidebar for all users with logout button in the corner
  if (typedUser.role === 'faculty') {
    return <FacultyDashboard user={typedUser} onLogout={handleLogout} />;
  }
  
  if (typedUser.role === 'student') {
    return (
      <div className="min-h-screen bg-slate-50 relative">
        <div className="absolute top-4 right-4 z-10">
          <button 
            onClick={handleLogout}
            className="px-4 py-2 rounded-md bg-slate-200 hover:bg-slate-300 text-slate-800 text-sm font-medium flex items-center"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M3 3a1 1 0 00-1 1v12a1 1 0 001 1h12a1 1 0 001-1V4a1 1 0 00-1-1H3zm2 12V5h10v10H5z" clipRule="evenodd" />
              <path fillRule="evenodd" d="M13.707 9.293a1 1 0 00-1.414 0L11 10.586V6a1 1 0 10-2 0v4.586l-1.293-1.293a1 1 0 00-1.414 1.414l3 3a1 1 0 001.414 0l3-3a1 1 0 000-1.414z" clipRule="evenodd" />
            </svg>
            Logout
          </button>
        </div>
        
        <div className="p-4 md:p-8">
          <div className="max-w-7xl mx-auto">
            <StudentDashboard user={typedUser} />
          </div>
        </div>
      </div>
    );
  }
  
  if (typedUser.role === 'admin') {
    return (
      <div className="min-h-screen bg-slate-50 relative">
        <div className="absolute top-4 right-4 z-10">
          <button 
            onClick={handleLogout}
            className="px-4 py-2 rounded-md bg-slate-200 hover:bg-slate-300 text-slate-800 text-sm font-medium flex items-center"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M3 3a1 1 0 00-1 1v12a1 1 0 001 1h12a1 1 0 001-1V4a1 1 0 00-1-1H3zm2 12V5h10v10H5z" clipRule="evenodd" />
              <path fillRule="evenodd" d="M13.707 9.293a1 1 0 00-1.414 0L11 10.586V6a1 1 0 10-2 0v4.586l-1.293-1.293a1 1 0 00-1.414 1.414l3 3a1 1 0 001.414 0l3-3a1 1 0 000-1.414z" clipRule="evenodd" />
            </svg>
            Logout
          </button>
        </div>
        
        <div className="p-4 md:p-8">
          <div className="max-w-7xl mx-auto">
            <AdminDashboard user={typedUser} />
          </div>
        </div>
      </div>
    );
  }
  
  return null;
};

export default Dashboard;
