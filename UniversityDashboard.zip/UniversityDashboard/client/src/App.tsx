import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";

import Login from "@/pages/Login";
import Dashboard from "@/pages/Dashboard";
import Home from "@/pages/Home";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/login" component={Login} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/assignments" component={Dashboard} />
      <Route path="/attendance" component={Dashboard} />
      <Route path="/grades" component={Dashboard} />
      <Route path="/announcements" component={Dashboard} />
      <Route path="/timetable" component={Dashboard} />
      <Route path="/profile" component={Dashboard} />
      <Route path="/students" component={Dashboard} />
      <Route path="/faculty" component={Dashboard} />
      <Route path="/courses" component={Dashboard} />
      <Route path="/timetables" component={Dashboard} />
      <Route path="/reports" component={Dashboard} />
      <Route path="/settings" component={Dashboard} />
      <Route path="/grading" component={Dashboard} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
