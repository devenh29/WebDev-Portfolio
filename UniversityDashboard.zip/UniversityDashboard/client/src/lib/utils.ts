import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: Date | string): string {
  if (typeof date === 'string') {
    date = new Date(date);
  }
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export function formatDateTime(date: Date | string): string {
  if (typeof date === 'string') {
    date = new Date(date);
  }
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function timeAgo(date: Date | string): string {
  if (typeof date === 'string') {
    date = new Date(date);
  }
  
  const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
  
  let interval = seconds / 31536000;
  if (interval > 1) {
    return Math.floor(interval) + " years ago";
  }
  
  interval = seconds / 2592000;
  if (interval > 1) {
    return Math.floor(interval) + " months ago";
  }
  
  interval = seconds / 86400;
  if (interval > 1) {
    return Math.floor(interval) + " days ago";
  }
  
  interval = seconds / 3600;
  if (interval > 1) {
    return Math.floor(interval) + " hours ago";
  }
  
  interval = seconds / 60;
  if (interval > 1) {
    return Math.floor(interval) + " minutes ago";
  }
  
  return Math.floor(seconds) + " seconds ago";
}

export function calculateAttendancePercentage(present: number, total: number): number {
  if (total === 0) return 0;
  return Math.round((present / total) * 100);
}

export function getAttendanceStatus(percentage: number): { 
  status: string; 
  color: string; 
  badge: "default" | "destructive" | "outline" | "secondary" | "success" | "warning" | "danger"; 
  icon: string 
} {
  if (percentage >= 90) {
    return { 
      status: "Excellent", 
      color: "bg-green-700", 
      badge: "success",
      icon: "🏆"
    };
  } else if (percentage >= 75) {
    return { 
      status: "Good", 
      color: "bg-green-500", 
      badge: "success",
      icon: "🟢"
    };
  } else if (percentage >= 60) {
    return { 
      status: "Average", 
      color: "bg-yellow-500", 
      badge: "warning",
      icon: "🟡"
    };
  } else {
    return { 
      status: "Poor", 
      color: "bg-red-500", 
      badge: "destructive",
      icon: "🔴"
    };
  }
}

export function getMotivationalQuote(performance: string): string {
  const quotes = {
    excellent: [
      "Excellence is not a skill. It's an attitude.",
      "Your dedication is truly paying off. Keep up the excellent work!",
      "Success is no accident. It is hard work, perseverance, learning, and passion.",
    ],
    good: [
      "Good, better, best. Never let it rest until your good is better and your better is best.",
      "You're doing great! Keep pushing your boundaries.",
      "Progress is impossible without consistent effort. You're on the right track!",
    ],
    average: [
      "Even the smallest step forward is a step in the right direction.",
      "Don't compare yourself to others, focus on your own improvement.",
      "Every master was once a beginner. Keep going!",
    ],
    poor: [
      "The greatest glory in living lies not in never falling, but in rising every time we fall.",
      "Challenges are what make life interesting. Overcoming them is what makes life meaningful.",
      "Don't worry about failures, worry about the chances you miss when you don't even try.",
    ]
  };

  let category = "average";
  if (performance === "A" || performance === "A+") {
    category = "excellent";
  } else if (performance === "B+" || performance === "B") {
    category = "good";
  } else if (performance === "C+" || performance === "C") {
    category = "average";
  } else {
    category = "poor";
  }

  const categoryQuotes = quotes[category as keyof typeof quotes];
  return categoryQuotes[Math.floor(Math.random() * categoryQuotes.length)];
}

export function getGradeColor(grade: string): string {
  switch (grade) {
    case "A+":
    case "A":
      return "bg-green-100 text-green-800";
    case "B+":
    case "B":
      return "bg-blue-100 text-blue-800";
    case "C+":
    case "C":
      return "bg-yellow-100 text-yellow-800";
    default:
      return "bg-red-100 text-red-800";
  }
}

export function getDaysLeft(dueDate: Date | string): { days: number; text: string; color: string } {
  if (typeof dueDate === 'string') {
    dueDate = new Date(dueDate);
  }
  
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const due = new Date(dueDate);
  due.setHours(0, 0, 0, 0);
  
  const differenceInTime = due.getTime() - today.getTime();
  const differenceInDays = Math.ceil(differenceInTime / (1000 * 3600 * 24));
  
  let text = `${differenceInDays} Days Left`;
  let color = "bg-yellow-100 text-yellow-800";
  
  if (differenceInDays < 0) {
    text = "Overdue";
    color = "bg-red-100 text-red-800";
  } else if (differenceInDays === 0) {
    text = "Due Today";
    color = "bg-red-100 text-red-800";
  } else if (differenceInDays === 1) {
    text = "Due Tomorrow";
    color = "bg-red-100 text-red-800";
  } else if (differenceInDays <= 3) {
    color = "bg-yellow-100 text-yellow-800";
  } else {
    color = "bg-green-100 text-green-800";
  }
  
  return { days: differenceInDays, text, color };
}

export function getWeeklyAttendance(attendanceRecords: any[], courseId?: number): { 
  present: number; 
  total: number; 
  percentage: number;
  status: { status: string; color: string; badge: "default" | "destructive" | "outline" | "secondary" | "success" | "warning" | "danger"; icon: string };
} {
  const now = new Date();
  const weekStart = new Date(now);
  weekStart.setDate(now.getDate() - now.getDay()); // Go to beginning of week (Sunday)
  weekStart.setHours(0, 0, 0, 0);
  
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekStart.getDate() + 6); // Go to end of week (Saturday)
  weekEnd.setHours(23, 59, 59, 999);
  
  // Filter records by date and course if specified
  let filteredRecords = attendanceRecords.filter(record => {
    const recordDate = new Date(record.date);
    return recordDate >= weekStart && recordDate <= weekEnd;
  });
  
  if (courseId) {
    filteredRecords = filteredRecords.filter(record => record.courseId === courseId);
  }
  
  const present = filteredRecords.filter(record => record.status === 'present').length;
  const total = filteredRecords.length;
  const percentage = calculateAttendancePercentage(present, total);
  const status = getAttendanceStatus(percentage);
  
  return { present, total, percentage, status };
}

export function getMonthlyAttendance(attendanceRecords: any[], courseId?: number): { 
  present: number; 
  total: number; 
  percentage: number;
  status: { status: string; color: string; badge: "default" | "destructive" | "outline" | "secondary" | "success" | "warning" | "danger"; icon: string };
} {
  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0);
  monthEnd.setHours(23, 59, 59, 999);
  
  // Filter records by date and course if specified
  let filteredRecords = attendanceRecords.filter(record => {
    const recordDate = new Date(record.date);
    return recordDate >= monthStart && recordDate <= monthEnd;
  });
  
  if (courseId) {
    filteredRecords = filteredRecords.filter(record => record.courseId === courseId);
  }
  
  const present = filteredRecords.filter(record => record.status === 'present').length;
  const total = filteredRecords.length;
  const percentage = calculateAttendancePercentage(present, total);
  const status = getAttendanceStatus(percentage);
  
  return { present, total, percentage, status };
}

export function getStudentAchievements(attendanceRecords: any[], grades: any[]): { 
  badges: Array<{ name: string; icon: string; description: string; color: string; }>;
  progress: number;
} {
  const badges = [];
  
  // Perfect Attendance Badge
  const allAttendance = attendanceRecords.filter(record => record.status === 'present').length;
  const totalAttendance = attendanceRecords.length;
  const attendancePercentage = calculateAttendancePercentage(allAttendance, totalAttendance);
  
  if (attendancePercentage >= 95) {
    badges.push({
      name: "Perfect Attendance",
      icon: "trophy",
      description: "Attended 95% or more of all classes",
      color: "bg-green-600"
    });
  } else if (attendancePercentage >= 90) {
    badges.push({
      name: "Excellent Attendance",
      icon: "medal",
      description: "Attended 90% or more of all classes",
      color: "bg-indigo-600"
    });
  }
  
  // Top Scorer Badge
  const topGrades = grades.filter(grade => grade.grade === "A+" || grade.grade === "A");
  if (topGrades.length > 0) {
    badges.push({
      name: "Top Scorer",
      icon: "star",
      description: `Achieved A+ in ${topGrades.length} subject${topGrades.length > 1 ? 's' : ''}`,
      color: "bg-amber-600"
    });
  }
  
  // Consistent Performer Badge
  const goodGrades = grades.filter(grade => 
    grade.grade === "A+" || grade.grade === "A" || grade.grade === "B+" || grade.grade === "B"
  );
  if (goodGrades.length === grades.length && grades.length > 0) {
    badges.push({
      name: "Consistent Performer",
      icon: "sparkles",
      description: "Maintained good grades across all subjects",
      color: "bg-purple-600"
    });
  }
  
  // Calculate overall progress
  // Combines attendance and grades to get a student progress percentage
  let progress = 0;
  
  // Calculate progress based on attendance
  const attendanceScore = Math.min(attendancePercentage, 100); // Cap at 100%
  
  // Calculate progress based on grades
  let gradeScore = 0;
  if (grades.length > 0) {
    const gradeValues = {
      "A+": 100, "A": 90, "B+": 85, "B": 80, 
      "C+": 75, "C": 70, "D+": 65, "D": 60, "F": 50
    };
    
    let totalPoints = 0;
    grades.forEach(grade => {
      totalPoints += gradeValues[grade.grade as keyof typeof gradeValues] || 50;
    });
    
    gradeScore = totalPoints / grades.length;
  }
  
  // Combine attendance and grade scores (50% weight each if both are present)
  if (totalAttendance > 0 && grades.length > 0) {
    progress = Math.round((attendanceScore * 0.5) + (gradeScore * 0.5));
  } else if (totalAttendance > 0) {
    progress = Math.round(attendanceScore);
  } else if (grades.length > 0) {
    progress = Math.round(gradeScore);
  }
  
  return { badges, progress };
}