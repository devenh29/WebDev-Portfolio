import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { motion } from 'framer-motion';
import { 
  BookOpen, Clock, GraduationCap, User, 
  Bell, Grid3X3, FileText, Calendar, 
  Download, Upload, Plus, HelpCircle,
  CheckCircle, AlertTriangle, Award, Trophy, 
  Sparkles, Medal, Star, BarChart3, Activity
} from 'lucide-react';

import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Separator } from '@/components/ui/separator';

import AnnouncementCard from '@/components/shared/AnnouncementCard';
import AssignmentCard from '@/components/shared/AssignmentCard';
import AttendanceChart from '@/components/shared/AttendanceChart';
import GradeTable from '@/components/shared/GradeTable';
import { 
  getMotivationalQuote, 
  getStudentAchievements, 
  getDaysLeft,
  getAttendanceStatus
} from '@/lib/utils';
import { User as UserType, Announcement, Course, Assignment, Attendance, Grade } from '@shared/schema';

interface StudentDashboardProps {
  user: UserType;
  onLogout?: () => void;
}

type ActiveSection = 'home' | 'assignments' | 'attendance' | 'grades' | 'profile' | 'announcements';

const StudentDashboard: React.FC<StudentDashboardProps> = ({ user, onLogout }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeSection, setActiveSection] = useState<ActiveSection>('home');
  
  // Fetch announcements
  const { data: announcements = [] } = useQuery<Announcement[]>({
    queryKey: ['/api/announcements'],
  });

  // Fetch courses for the student
  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ['/api/courses'],
  });

  // Fetch assignments for the student
  const { data: assignments = [] } = useQuery<Assignment[]>({
    queryKey: ['/api/assignments'],
    queryFn: async ({ queryKey }) => {
      // Fetch assignments for all student's courses
      const response = await fetch(`${queryKey[0]}?courseId=1`);
      if (!response.ok) throw new Error('Failed to fetch assignments');
      return response.json();
    }
  });

  // Fetch attendance for the student
  const { data: attendance = [] } = useQuery<Attendance[]>({
    queryKey: ['/api/attendance'],
    queryFn: async ({ queryKey }) => {
      const response = await fetch(`${queryKey[0]}?studentId=${user.id}`);
      if (!response.ok) throw new Error('Failed to fetch attendance');
      return response.json();
    }
  });

  // Fetch grades for the student
  const { data: grades = [] } = useQuery<Grade[]>({
    queryKey: ['/api/grades'],
    queryFn: async ({ queryKey }) => {
      const response = await fetch(`${queryKey[0]}?studentId=${user.id}`);
      if (!response.ok) throw new Error('Failed to fetch grades');
      return response.json();
    }
  });
  
  // Upload assignment mutation
  const uploadAssignmentMutation = useMutation({
    mutationFn: async (assignmentId: number) => {
      const response = await fetch('/api/student-assignments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          assignmentId,
          studentId: user.id,
          submissionText: 'Assignment submitted by student',
          submissionDate: new Date().toISOString(),
          status: 'submitted'
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to submit assignment');
      }
      
      return response.json();
    },
    onSuccess: () => {
      // Invalidate queries to refresh the data
      queryClient.invalidateQueries({ queryKey: ['/api/assignments'] });
      toast({
        title: "Success!",
        description: "Assignment submitted successfully",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to submit assignment: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  // Get average grade for motivational quote
  const averageGrade = grades.length > 0 ? (grades[0].grade || 'B+') : 'B+';
  const motivationalQuote = getMotivationalQuote(averageGrade);

  // Navigation buttons
  const renderNavigationButtons = () => (
    <div className="grid grid-cols-3 md:grid-cols-6 gap-4 mb-8">
      <Button 
        variant={activeSection === 'home' ? 'default' : 'outline'} 
        className="flex flex-col items-center justify-center h-24 p-2"
        onClick={() => setActiveSection('home')}
      >
        <Grid3X3 className="h-8 w-8 mb-2" />
        <span>Dashboard</span>
      </Button>
      
      <Button 
        variant={activeSection === 'assignments' ? 'default' : 'outline'} 
        className="flex flex-col items-center justify-center h-24 p-2"
        onClick={() => setActiveSection('assignments')}
      >
        <FileText className="h-8 w-8 mb-2" />
        <span>Assignments</span>
      </Button>
      
      <Button 
        variant={activeSection === 'attendance' ? 'default' : 'outline'} 
        className="flex flex-col items-center justify-center h-24 p-2"
        onClick={() => setActiveSection('attendance')}
      >
        <Clock className="h-8 w-8 mb-2" />
        <span>Attendance</span>
      </Button>
      
      <Button 
        variant={activeSection === 'grades' ? 'default' : 'outline'} 
        className="flex flex-col items-center justify-center h-24 p-2"
        onClick={() => setActiveSection('grades')}
      >
        <GraduationCap className="h-8 w-8 mb-2" />
        <span>Grades</span>
      </Button>
      
      <Button 
        variant={activeSection === 'profile' ? 'default' : 'outline'} 
        className="flex flex-col items-center justify-center h-24 p-2"
        onClick={() => setActiveSection('profile')}
      >
        <User className="h-8 w-8 mb-2" />
        <span>Profile</span>
      </Button>
      
      <Button 
        variant={activeSection === 'announcements' ? 'default' : 'outline'} 
        className="flex flex-col items-center justify-center h-24 p-2"
        onClick={() => setActiveSection('announcements')}
      >
        <Bell className="h-8 w-8 mb-2" />
        <span>Announcements</span>
      </Button>
    </div>
  );

  // Section components
  const renderHomeSection = () => {
    const achievements = getStudentAchievements(attendance, grades);
    
    return (
      <div className="space-y-6">
        <Card className="bg-gradient-to-r from-indigo-50 to-slate-50 border-none overflow-hidden relative">
          <div className="absolute right-0 bottom-0 w-32 h-32 text-indigo-100">
            <GraduationCap className="w-full h-full opacity-20" />
          </div>
          <CardContent className="p-6">
            <h2 className="text-2xl font-bold text-slate-800">Welcome, {user.firstName}!</h2>
            <p className="text-slate-600 mb-4 max-w-2xl">
              Today is {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}.
            </p>
            
            <div className="mt-4 text-sm font-medium text-indigo-600">
              <span className="italic">"{motivationalQuote}"</span>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-bold flex items-center">
                <Clock className="mr-2 h-5 w-5 text-indigo-500" />
                Today's Schedule
              </CardTitle>
              <CardDescription>Your upcoming classes and events</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="bg-slate-50 p-3 rounded-md border border-slate-200">
                  <div className="flex justify-between">
                    <div>
                      <div className="font-medium text-sm">Database Systems</div>
                      <div className="text-xs text-slate-500">Dr. Johnson • Room 302</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-medium">10:30 AM</div>
                      <div className="text-xs text-slate-500">Today</div>
                    </div>
                  </div>
                </div>
                <div className="bg-slate-50 p-3 rounded-md border border-slate-200">
                  <div className="flex justify-between">
                    <div>
                      <div className="font-medium text-sm">Algorithms</div>
                      <div className="text-xs text-slate-500">Prof. Williams • Lab 204</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-medium">1:15 PM</div>
                      <div className="text-xs text-slate-500">Today</div>
                    </div>
                  </div>
                </div>
                <div className="bg-slate-50 p-3 rounded-md border border-slate-200">
                  <div className="flex justify-between">
                    <div>
                      <div className="font-medium text-sm">Software Engineering</div>
                      <div className="text-xs text-slate-500">Dr. Thompson • Room 105</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-medium">3:30 PM</div>
                      <div className="text-xs text-slate-500">Today</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-bold flex items-center">
                <Award className="mr-2 h-5 w-5 text-indigo-500" />
                Your Achievements
              </CardTitle>
              <CardDescription>Badges and milestones you've earned</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                {achievements.badges.map((badge, index) => (
                  <div key={index} className="bg-slate-50 p-3 rounded-md border border-slate-200 flex items-center">
                    <div className={`rounded-full h-10 w-10 flex items-center justify-center ${badge.color}`}>
                      {badge.icon === 'trophy' && <Trophy className="h-5 w-5 text-white" />}
                      {badge.icon === 'sparkles' && <Sparkles className="h-5 w-5 text-white" />}
                      {badge.icon === 'medal' && <Medal className="h-5 w-5 text-white" />}
                      {badge.icon === 'star' && <Star className="h-5 w-5 text-white" />}
                    </div>
                    <div className="ml-3">
                      <div className="text-sm font-medium">{badge.name}</div>
                      <div className="text-xs text-slate-500">{badge.description}</div>
                    </div>
                  </div>
                ))}
                
                {achievements.badges.length === 0 && (
                  <div className="col-span-2 text-center py-6 text-slate-500">
                    Complete assignments and attend classes to earn badges!
                  </div>
                )}
              </div>
            </CardContent>
            <CardFooter className="border-t pt-4">
              <div className="w-full">
                <div className="text-sm font-medium mb-2">Overall Progress</div>
                <div className="flex items-center space-x-2">
                  <div className="flex-1">
                    <Progress value={achievements.progress} className="h-2" />
                  </div>
                  <div className="text-sm text-slate-500">{achievements.progress}%</div>
                </div>
              </div>
            </CardFooter>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-md font-medium flex items-center">
                <FileText className="mr-2 h-5 w-5 text-indigo-500" />
                Assignments
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm">Pending</span>
                <Badge variant="outline" className="bg-indigo-50 text-indigo-600">
                  {assignments.filter(a => !a.submitted).length}
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Due This Week</span>
                <Badge variant="outline" className="bg-amber-50 text-amber-600">
                  {assignments.filter(a => {
                    const dueDate = new Date(a.dueDate);
                    const today = new Date();
                    const nextWeek = new Date(today);
                    nextWeek.setDate(today.getDate() + 7);
                    return dueDate >= today && dueDate <= nextWeek && !a.submitted;
                  }).length}
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Completed</span>
                <Badge variant="outline" className="bg-green-50 text-green-600">
                  {assignments.filter(a => a.submitted).length}
                </Badge>
              </div>
            </CardContent>
            <CardFooter className="pt-0">
              <Button variant="ghost" size="sm" className="w-full justify-center" onClick={() => setActiveSection('assignments')}>
                View All
              </Button>
            </CardFooter>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-md font-medium flex items-center">
                <BarChart3 className="mr-2 h-5 w-5 text-indigo-500" />
                Attendance
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {courses.slice(0, 3).map((course) => {
                const courseAttendance = attendance.filter((a) => a.courseId === course.id);
                const present = courseAttendance.filter((a) => a.status === 'present').length;
                const total = courseAttendance.length || 1; // Avoid division by zero
                const percentage = Math.round((present / total) * 100);
                const status = getAttendanceStatus(percentage);
                
                return (
                  <div key={course.id} className="space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="text-sm truncate" title={course.name}>
                        {course.name.length > 20 ? course.name.substring(0, 20) + '...' : course.name}
                      </span>
                      <Badge variant={status.badge}>{percentage}%</Badge>
                    </div>
                    <Progress value={percentage} className="h-1" />
                  </div>
                );
              })}
            </CardContent>
            <CardFooter className="pt-0">
              <Button variant="ghost" size="sm" className="w-full justify-center" onClick={() => setActiveSection('attendance')}>
                View Details
              </Button>
            </CardFooter>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-md font-medium flex items-center">
                <Bell className="mr-2 h-5 w-5 text-indigo-500" />
                Announcements
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {announcements.slice(0, 2).map((announcement, index) => (
                <div key={announcement.id} className="space-y-1">
                  <div className="flex items-center">
                    {index === 0 && (
                      <Badge className="mr-2 bg-red-100 text-red-700 hover:bg-red-100">New</Badge>
                    )}
                    <h4 className="text-sm font-medium truncate" title={announcement.title}>
                      {announcement.title.length > 25 ? announcement.title.substring(0, 25) + '...' : announcement.title}
                    </h4>
                  </div>
                  <p className="text-xs text-slate-500">
                    {announcement.createdAt ? new Date(announcement.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : 'Recently'}
                  </p>
                </div>
              ))}
              
              {announcements.length === 0 && (
                <div className="text-center py-4 text-slate-500">
                  No announcements
                </div>
              )}
            </CardContent>
            <CardFooter className="pt-0">
              <Button variant="ghost" size="sm" className="w-full justify-center" onClick={() => setActiveSection('announcements')}>
                View All
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    );
  };

  const renderAssignmentsSection = () => {
    // Calculate assignments status counts
    const pendingAssignments = assignments.filter(a => !a.submitted);
    const submittedAssignments = assignments.filter(a => a.submitted && !a.graded);
    const gradedAssignments = assignments.filter(a => a.submitted && a.graded);
    
    // Sort assignments by due date (most urgent first)
    const sortedAssignments = [...assignments].sort((a, b) => {
      const dateA = new Date(a.dueDate);
      const dateB = new Date(b.dueDate);
      return dateA.getTime() - dateB.getTime();
    });
    
    // Get upcoming assignments with deadlines in next 7 days
    const today = new Date();
    const nextWeek = new Date(today);
    nextWeek.setDate(today.getDate() + 7);
    
    const upcomingAssignments = sortedAssignments.filter(a => {
      const dueDate = new Date(a.dueDate);
      return dueDate >= today && dueDate <= nextWeek && !a.submitted;
    });
    
    return (
      <div className="space-y-6">
        {/* Assignment Status Overview */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg font-bold flex items-center">
              <FileText className="mr-2 h-5 w-5 text-indigo-500" />
              Assignment Tracker
            </CardTitle>
            <CardDescription>Track your upcoming assignments and submission status</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-medium text-slate-800">Pending</h3>
                  <Badge variant="outline" className="bg-indigo-50 text-indigo-600">
                    {pendingAssignments.length}
                  </Badge>
                </div>
                <div className="text-sm text-slate-600">Assignments yet to be submitted</div>
              </div>
              
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-medium text-slate-800">Submitted</h3>
                  <Badge variant="outline" className="bg-green-50 text-green-600">
                    {submittedAssignments.length}
                  </Badge>
                </div>
                <div className="text-sm text-slate-600">Waiting for grading</div>
              </div>
              
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-medium text-slate-800">Graded</h3>
                  <Badge variant="outline" className="bg-blue-50 text-blue-600">
                    {gradedAssignments.length}
                  </Badge>
                </div>
                <div className="text-sm text-slate-600">Received feedback and grades</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Upcoming Deadlines */}
        {upcomingAssignments.length > 0 && (
          <Card className="bg-amber-50 border-amber-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-md font-medium flex items-center text-amber-800">
                <AlertTriangle className="mr-2 h-5 w-5 text-amber-600" />
                Upcoming Deadlines
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {upcomingAssignments.map((assignment) => {
                  const course = courses.find((c) => c.id === assignment.courseId) || { name: 'Unknown Course' };
                  const daysInfo = getDaysLeft(assignment.dueDate);
                  
                  return (
                    <div key={assignment.id} className="flex items-center justify-between bg-white p-3 rounded-md border border-amber-200">
                      <div>
                        <div className="font-medium">{assignment.title}</div>
                        <div className="text-xs text-slate-500">{course.name}</div>
                      </div>
                      <Badge className={daysInfo.color}>
                        {daysInfo.text}
                      </Badge>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}
        
        {/* All Assignments */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg font-bold">All Assignments</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all">
              <TabsList className="mb-4">
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="pending">Pending</TabsTrigger>
                <TabsTrigger value="submitted">Submitted</TabsTrigger>
                <TabsTrigger value="graded">Graded</TabsTrigger>
              </TabsList>
              
              <TabsContent value="all" className="space-y-4">
                {sortedAssignments.map((assignment) => {
                  const course = courses.find((c) => c.id === assignment.courseId) || { name: 'Unknown Course', type: 'theory' };
                  return (
                    <AssignmentCard
                      key={assignment.id}
                      assignment={assignment}
                      courseName={course.name}
                      assignmentType={course.type}
                      onClick={() => toast({
                        title: "Assignment Details",
                        description: `Viewing details for ${assignment.title}`,
                      })}
                      onUpload={(assignmentId) => {
                        uploadAssignmentMutation.mutate(assignmentId);
                      }}
                    />
                  );
                })}
                
                {assignments.length === 0 && (
                  <div className="text-center py-8 text-slate-500">
                    No assignments available
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="pending" className="space-y-4">
                {pendingAssignments.map((assignment) => {
                  const course = courses.find((c) => c.id === assignment.courseId) || { name: 'Unknown Course', type: 'theory' };
                  return (
                    <AssignmentCard
                      key={assignment.id}
                      assignment={assignment}
                      courseName={course.name}
                      assignmentType={course.type}
                      onClick={() => toast({
                        title: "Submit Assignment",
                        description: `Upload your submission for ${assignment.title}`,
                      })}
                      onUpload={(assignmentId) => {
                        uploadAssignmentMutation.mutate(assignmentId);
                      }}
                    />
                  );
                })}
                
                {pendingAssignments.length === 0 && (
                  <div className="text-center py-8 text-slate-500">
                    No pending assignments
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="submitted" className="space-y-4">
                {submittedAssignments.map((assignment) => {
                  const course = courses.find((c) => c.id === assignment.courseId) || { name: 'Unknown Course', type: 'theory' };
                  return (
                    <AssignmentCard
                      key={assignment.id}
                      assignment={assignment}
                      courseName={course.name}
                      assignmentType={course.type}
                      onClick={() => toast({
                        title: "Submission Details",
                        description: `View your submission for ${assignment.title}`,
                      })}
                    />
                  );
                })}
                
                {submittedAssignments.length === 0 && (
                  <div className="text-center py-8 text-slate-500">
                    No submitted assignments waiting for feedback
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="graded" className="space-y-4">
                {gradedAssignments.map((assignment) => {
                  const course = courses.find((c) => c.id === assignment.courseId) || { name: 'Unknown Course', type: 'theory' };
                  return (
                    <AssignmentCard
                      key={assignment.id}
                      assignment={assignment}
                      courseName={course.name}
                      assignmentType={course.type}
                      onClick={() => toast({
                        title: "View Feedback",
                        description: `Check your grade and feedback for ${assignment.title}`,
                      })}
                    />
                  );
                })}
                
                {gradedAssignments.length === 0 && (
                  <div className="text-center py-8 text-slate-500">
                    No graded assignments yet
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
          
          <CardFooter className="border-t pt-6">
            <div className="w-full flex justify-between items-center">
              <span className="text-sm text-slate-500">Total: {assignments.length} assignments</span>
            </div>
          </CardFooter>
        </Card>
      </div>
    );
  };

  const renderAttendanceSection = () => (
    <div>
      <AttendanceChart attendanceRecords={attendance} courses={courses} />
    </div>
  );

  const renderGradesSection = () => (
    <Card className="mb-6">
      <CardContent className="p-5">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-lg font-bold text-slate-800">Your Grades</h2>
          <div className="flex items-center">
            <span className="text-sm text-slate-500 mr-2">Term:</span>
            <Select defaultValue="Fall 2023">
              <SelectTrigger className="text-sm border border-slate-300 rounded-md h-8 min-w-[150px]">
                <SelectValue placeholder="Select term" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Fall 2023">Fall 2023</SelectItem>
                <SelectItem value="Spring 2023">Spring 2023</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <GradeTable grades={grades} courses={courses} term="Fall 2023" />
        </div>
        
        <div className="mt-6 bg-slate-50 p-4 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-md font-medium text-slate-800">Overall Performance</h3>
              <p className="text-sm text-slate-600">Track your progress in all subjects</p>
            </div>
            <div className="text-right">
              <div className="text-sm text-slate-600 italic">"{motivationalQuote}"</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  const renderProfileSection = () => (
    <Card className="mb-6">
      <CardContent className="p-5">
        <h2 className="text-lg font-bold text-slate-800 mb-4">Your Profile</h2>
        
        <div className="flex flex-col md:flex-row items-start gap-6">
          <div className="bg-slate-100 rounded-full h-32 w-32 flex items-center justify-center">
            <User className="h-16 w-16 text-slate-400" />
          </div>
          
          <div className="flex-1 space-y-4">
            <div>
              <h3 className="text-sm font-medium text-slate-500">Full Name</h3>
              <p className="text-lg">{user.firstName} {user.lastName}</p>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-slate-500">Student ID</h3>
              <p className="text-lg">{user.id}</p>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-slate-500">Email</h3>
              <p className="text-lg">{user.username}@university.edu</p>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-slate-500">Department</h3>
              <p className="text-lg">Computer Science</p>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-slate-500">Joined</h3>
              <p className="text-lg">September 2023</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  const renderAnnouncementsSection = () => (
    <Card className="mb-6">
      <CardContent className="p-5">
        <h2 className="text-lg font-bold text-slate-800 mb-4">Announcements</h2>
        
        <div className="space-y-4">
          {announcements.map((announcement: Announcement, index: number) => (
            <AnnouncementCard 
              key={announcement.id}
              announcement={announcement}
              isNew={index === 0}
            />
          ))}
          
          {announcements.length === 0 && (
            <div className="text-center py-8 text-slate-500">
              No announcements available
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );

  // Render the active section
  const renderActiveSection = () => {
    switch (activeSection) {
      case 'home':
        return renderHomeSection();
      case 'assignments':
        return renderAssignmentsSection();
      case 'attendance':
        return renderAttendanceSection();
      case 'grades':
        return renderGradesSection();
      case 'profile':
        return renderProfileSection();
      case 'announcements':
        return renderAnnouncementsSection();
      default:
        return renderHomeSection();
    }
  };

  return (
    <div>
      <div className="mb-6 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 font-heading">Student Portal</h1>
          <p className="text-slate-500">Welcome, {user.firstName}!</p>
        </div>
        
        {onLogout && (
          <Button 
            onClick={onLogout}
            variant="outline"
            className="flex items-center gap-2"
          >
            <span>Logout</span>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
              <polyline points="16 17 21 12 16 7" />
              <line x1="21" y1="12" x2="9" y2="12" />
            </svg>
          </Button>
        )}
      </div>
      
      {renderNavigationButtons()}
      {renderActiveSection()}
    </div>
  );
};

export default StudentDashboard;
