import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { 
  User, BookOpen, Clock, GraduationCap, 
  Bell, Grid3X3, CheckCircle, XCircle, Edit, Download, 
  BarChart2, ClipboardList, Save, Calendar, Search,
  FileSpreadsheet, ListFilter, AlertTriangle, PieChart,
  BookCopy, UsersRound, Layers, BarChart, Clipboard, X,
  LogOut
} from 'lucide-react';

import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { User as UserType } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';

interface FacultyDashboardProps {
  user: UserType;
  onLogout: () => void;
}

type ActiveSection = 'dashboard' | 'courses' | 'students' | 'attendance' | 'assignments' | 'grades' | 'reports';

const FacultyDashboard: React.FC<FacultyDashboardProps> = ({ user, onLogout }) => {
  const { toast } = useToast();
  const [activeSection, setActiveSection] = useState<ActiveSection>('dashboard');
  const [activeTab, setActiveTab] = useState<'theory' | 'lab'>('theory');
  const [searchRollNo, setSearchRollNo] = useState<string>('');
  
  // Fetch students
  const { data: students = [] } = useQuery({
    queryKey: ['/api/users'],
    queryFn: async ({ queryKey }) => {
      const response = await fetch(`${queryKey[0]}?role=student`);
      if (!response.ok) throw new Error('Failed to fetch students');
      return response.json();
    }
  });

  // Fetch courses taught by the faculty
  const { data: courses = [] } = useQuery({
    queryKey: ['/api/courses'],
    queryFn: async ({ queryKey }) => {
      const response = await fetch(`${queryKey[0]}?department=${user.department}`);
      if (!response.ok) throw new Error('Failed to fetch courses');
      return response.json();
    }
  });

  // Fetch assignments created by the faculty
  const { data: assignments = [] } = useQuery({
    queryKey: ['/api/assignments'],
    queryFn: async ({ queryKey }) => {
      const response = await fetch(`${queryKey[0]}?facultyId=${user.id}`);
      if (!response.ok) throw new Error('Failed to fetch assignments');
      return response.json();
    }
  });
  
  // Filter students by roll number
  // Calculate filtered students directly without using state and useEffect to avoid infinite re-renders
  const filteredStudents = React.useMemo(() => {
    if (searchRollNo.trim() === '') {
      return students;
    } else {
      return students.filter((student: any) => 
        `S${student.id}`.toLowerCase().includes(searchRollNo.toLowerCase())
      );
    }
  }, [searchRollNo, students]);

  // Filter courses by type (theory or lab)
  const theoryCourses = courses.filter((course: any) => course.type === 'theory');
  const labCourses = courses.filter((course: any) => course.type === 'lab');

  // Define type for the array of sections to avoid TypeScript errors
  const navigationSections: { id: ActiveSection, label: string, icon: React.ReactNode }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <BarChart2 className="h-4 w-4" /> },
    { id: 'courses', label: 'Courses & Divisions', icon: <BookCopy className="h-4 w-4" /> },
    { id: 'students', label: 'Students', icon: <UsersRound className="h-4 w-4" /> },
    { id: 'attendance', label: 'Attendance', icon: <Clock className="h-4 w-4" /> },
    { id: 'assignments', label: 'Assignments', icon: <ClipboardList className="h-4 w-4" /> },
    { id: 'grades', label: 'Marks & Performance', icon: <GraduationCap className="h-4 w-4" /> },
    { id: 'reports', label: 'Reports', icon: <FileSpreadsheet className="h-4 w-4" /> }
  ];

  // Render teacher profile section
  const renderProfileSection = () => (
    <div>
      <Card className="mb-6">
        <CardContent className="p-5">
          <div className="flex flex-col md:flex-row gap-6 items-center md:items-start">
            <div className="bg-slate-100 rounded-full h-32 w-32 flex items-center justify-center">
              <User className="h-16 w-16 text-slate-400" />
            </div>
            
            <div className="flex-1 space-y-4 text-center md:text-left">
              <div>
                <h2 className="text-2xl font-bold text-slate-800">{user.firstName} {user.lastName}</h2>
                <p className="text-slate-500">{user.department} Department</p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-slate-500">Faculty ID</h3>
                  <p className="text-lg">F{user.id}</p>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-slate-500">Email</h3>
                  <p className="text-lg">{user.username}@university.edu</p>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-slate-500">Joined</h3>
                  <p className="text-lg">January 2021</p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8">
            <h3 className="text-lg font-bold text-slate-800 mb-4">Courses Teaching</h3>
            
            <Tabs defaultValue="theory" className="w-full" onValueChange={(value) => setActiveTab(value as 'theory' | 'lab')}>
              <TabsList className="grid w-full grid-cols-2 mb-4">
                <TabsTrigger value="theory">Theory Courses</TabsTrigger>
                <TabsTrigger value="lab">Lab Courses</TabsTrigger>
              </TabsList>
              
              <TabsContent value="theory">
                <div className="grid grid-cols-1 gap-4">
                  {theoryCourses.map((course: any) => (
                    <Card key={course.id} className="overflow-hidden">
                      <CardContent className="p-0">
                        <div className="bg-indigo-50 p-4">
                          <h4 className="font-medium text-lg text-slate-800">{course.name} ({course.code})</h4>
                          <p className="text-sm text-slate-600">Department: {course.department}</p>
                        </div>
                        
                        <div className="p-4">
                          <h5 className="font-medium text-slate-800 mb-3">Lecture Attendance</h5>
                          <div className="overflow-x-auto">
                            <Table>
                              <TableHeader>
                                <TableRow>
                                  <TableHead className="w-[80px]">Lecture</TableHead>
                                  {Array.from({ length: 15 }, (_, i) => (
                                    <TableHead key={i} className="text-center w-[50px]">{i + 1}</TableHead>
                                  ))}
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                <TableRow>
                                  <TableCell className="font-medium">Status</TableCell>
                                  {Array.from({ length: 15 }, (_, i) => (
                                    <TableCell key={i} className="text-center">
                                      <Checkbox 
                                        defaultChecked={i < 8} 
                                        onCheckedChange={() => toast({
                                          title: "Attendance Updated",
                                          description: `Lecture ${i + 1} attendance has been updated.`,
                                          variant: "default"
                                        })}
                                      />
                                    </TableCell>
                                  ))}
                                </TableRow>
                              </TableBody>
                            </Table>
                          </div>
                          
                          <h5 className="font-medium text-slate-800 mt-6 mb-3">Assignment Status</h5>
                          <div className="overflow-x-auto">
                            <Table>
                              <TableHeader>
                                <TableRow>
                                  <TableHead className="w-[150px]">Assignment</TableHead>
                                  <TableHead className="text-center">Given</TableHead>
                                  <TableHead className="text-center">Submitted</TableHead>
                                  <TableHead className="text-center">Checked</TableHead>
                                  <TableHead className="text-center">Actions</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {Array.from({ length: 3 }, (_, i) => (
                                  <TableRow key={i}>
                                    <TableCell className="font-medium">Assignment {i + 1}</TableCell>
                                    <TableCell className="text-center">
                                      <CheckCircle className="h-5 w-5 text-green-500 inline-block" />
                                    </TableCell>
                                    <TableCell className="text-center">
                                      {i < 2 ? (
                                        <CheckCircle className="h-5 w-5 text-green-500 inline-block" />
                                      ) : (
                                        <XCircle className="h-5 w-5 text-red-500 inline-block" />
                                      )}
                                    </TableCell>
                                    <TableCell className="text-center">
                                      {i === 0 ? (
                                        <CheckCircle className="h-5 w-5 text-green-500 inline-block" />
                                      ) : (
                                        <XCircle className="h-5 w-5 text-red-500 inline-block" />
                                      )}
                                    </TableCell>
                                    <TableCell className="text-center">
                                      <Button variant="outline" size="sm" className="mr-1"
                                        onClick={() => toast({
                                          title: "Edit Assignment",
                                          description: `Editing Assignment ${i + 1}`,
                                          variant: "default"
                                        })}
                                      >
                                        <Edit className="h-4 w-4" />
                                      </Button>
                                      <Button variant="outline" size="sm"
                                        onClick={() => toast({
                                          title: "Download Submissions",
                                          description: `Downloading submissions for Assignment ${i + 1}`,
                                          variant: "default"
                                        })}
                                      >
                                        <Download className="h-4 w-4" />
                                      </Button>
                                    </TableCell>
                                  </TableRow>
                                ))}
                              </TableBody>
                            </Table>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  
                  {theoryCourses.length === 0 && (
                    <div className="text-center py-8 text-slate-500">
                      No theory courses assigned
                    </div>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="lab">
                <div className="grid grid-cols-1 gap-4">
                  {labCourses.map((course: any) => (
                    <Card key={course.id} className="overflow-hidden">
                      <CardContent className="p-0">
                        <div className="bg-blue-50 p-4">
                          <h4 className="font-medium text-lg text-slate-800">{course.name} Lab ({course.code})</h4>
                          <p className="text-sm text-slate-600">Department: {course.department}</p>
                        </div>
                        
                        <div className="p-4">
                          <h5 className="font-medium text-slate-800 mb-3">Lab Session Attendance</h5>
                          <div className="overflow-x-auto">
                            <Table>
                              <TableHeader>
                                <TableRow>
                                  <TableHead className="w-[80px]">Session</TableHead>
                                  {Array.from({ length: 15 }, (_, i) => (
                                    <TableHead key={i} className="text-center w-[50px]">{i + 1}</TableHead>
                                  ))}
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                <TableRow>
                                  <TableCell className="font-medium">Status</TableCell>
                                  {Array.from({ length: 15 }, (_, i) => (
                                    <TableCell key={i} className="text-center">
                                      <Checkbox 
                                        defaultChecked={i < 7} 
                                        onCheckedChange={() => toast({
                                          title: "Attendance Updated",
                                          description: `Lab Session ${i + 1} attendance has been updated.`,
                                          variant: "default"
                                        })}
                                      />
                                    </TableCell>
                                  ))}
                                </TableRow>
                              </TableBody>
                            </Table>
                          </div>
                          
                          <h5 className="font-medium text-slate-800 mt-6 mb-3">Lab Assignment Status</h5>
                          <div className="overflow-x-auto">
                            <Table>
                              <TableHeader>
                                <TableRow>
                                  <TableHead className="w-[150px]">Lab Work</TableHead>
                                  <TableHead className="text-center">Given</TableHead>
                                  <TableHead className="text-center">Submitted</TableHead>
                                  <TableHead className="text-center">Checked</TableHead>
                                  <TableHead className="text-center">Actions</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {Array.from({ length: 3 }, (_, i) => (
                                  <TableRow key={i}>
                                    <TableCell className="font-medium">Lab {i + 1}</TableCell>
                                    <TableCell className="text-center">
                                      <CheckCircle className="h-5 w-5 text-green-500 inline-block" />
                                    </TableCell>
                                    <TableCell className="text-center">
                                      {i < 2 ? (
                                        <CheckCircle className="h-5 w-5 text-green-500 inline-block" />
                                      ) : (
                                        <XCircle className="h-5 w-5 text-red-500 inline-block" />
                                      )}
                                    </TableCell>
                                    <TableCell className="text-center">
                                      {i === 0 ? (
                                        <CheckCircle className="h-5 w-5 text-green-500 inline-block" />
                                      ) : (
                                        <XCircle className="h-5 w-5 text-red-500 inline-block" />
                                      )}
                                    </TableCell>
                                    <TableCell className="text-center">
                                      <Button variant="outline" size="sm" className="mr-1"
                                        onClick={() => toast({
                                          title: "Edit Lab",
                                          description: `Editing Lab ${i + 1}`,
                                          variant: "default"
                                        })}
                                      >
                                        <Edit className="h-4 w-4" />
                                      </Button>
                                      <Button variant="outline" size="sm"
                                        onClick={() => toast({
                                          title: "Download Submissions",
                                          description: `Downloading submissions for Lab ${i + 1}`,
                                          variant: "default"
                                        })}
                                      >
                                        <Download className="h-4 w-4" />
                                      </Button>
                                    </TableCell>
                                  </TableRow>
                                ))}
                              </TableBody>
                            </Table>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  
                  {labCourses.length === 0 && (
                    <div className="text-center py-8 text-slate-500">
                      No lab courses assigned
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  // Render assignments section
  const renderAssignmentsSection = () => (
    <Card className="mb-6">
      <CardContent className="p-5">
        <h2 className="text-xl font-bold text-slate-800 mb-6">Assignment Management</h2>
        
        <Tabs defaultValue="theory">
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="theory">Theory Courses</TabsTrigger>
            <TabsTrigger value="lab">Lab Courses</TabsTrigger>
          </TabsList>
          
          <TabsContent value="theory">
            {theoryCourses.map((course: any) => (
              <div key={course.id} className="mb-8">
                <h3 className="text-lg font-medium text-slate-800 mb-4">{course.name} ({course.code})</h3>
                
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Assignment</TableHead>
                        <TableHead>Deadline</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Submissions</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {Array.from({ length: 3 }, (_, i) => (
                        <TableRow key={i}>
                          <TableCell className="font-medium">Assignment {i + 1}: Topic {i + 1}</TableCell>
                          <TableCell>
                            {new Date(2025, 3, 10 + i * 7).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                          </TableCell>
                          <TableCell>
                            {i === 0 ? (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                Completed
                              </span>
                            ) : i === 1 ? (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                                In Progress
                              </span>
                            ) : (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                Upcoming
                              </span>
                            )}
                          </TableCell>
                          <TableCell>{45 - i * 5}/45</TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button variant="outline" size="sm"
                                onClick={() => toast({
                                  title: "Edit Assignment",
                                  description: `Editing Assignment ${i + 1}`,
                                  variant: "default"
                                })}
                              >
                                <Edit className="h-4 w-4 mr-1" />
                                Edit
                              </Button>
                              <Button variant="outline" size="sm"
                                onClick={() => toast({
                                  title: "Grade Assignment",
                                  description: `Grading Assignment ${i + 1}`,
                                  variant: "default"
                                })}
                              >
                                <GraduationCap className="h-4 w-4 mr-1" />
                                Grade
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                
                <Button 
                  className="mt-4"
                  onClick={() => toast({
                    title: "Create Assignment",
                    description: `Creating new assignment for ${course.name}`,
                    variant: "default"
                  })}
                >
                  Create New Assignment
                </Button>
              </div>
            ))}
          </TabsContent>
          
          <TabsContent value="lab">
            {labCourses.map((course: any) => (
              <div key={course.id} className="mb-8">
                <h3 className="text-lg font-medium text-slate-800 mb-4">{course.name} Lab ({course.code})</h3>
                
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Lab Work</TableHead>
                        <TableHead>Deadline</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Submissions</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {Array.from({ length: 3 }, (_, i) => (
                        <TableRow key={i}>
                          <TableCell className="font-medium">Lab {i + 1}: Practical {i + 1}</TableCell>
                          <TableCell>
                            {new Date(2025, 3, 12 + i * 7).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                          </TableCell>
                          <TableCell>
                            {i === 0 ? (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                Completed
                              </span>
                            ) : i === 1 ? (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                                In Progress
                              </span>
                            ) : (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                Upcoming
                              </span>
                            )}
                          </TableCell>
                          <TableCell>{30 - i * 3}/30</TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button variant="outline" size="sm"
                                onClick={() => toast({
                                  title: "Edit Lab",
                                  description: `Editing Lab ${i + 1}`,
                                  variant: "default"
                                })}
                              >
                                <Edit className="h-4 w-4 mr-1" />
                                Edit
                              </Button>
                              <Button variant="outline" size="sm"
                                onClick={() => toast({
                                  title: "Grade Lab",
                                  description: `Grading Lab ${i + 1}`,
                                  variant: "default"
                                })}
                              >
                                <GraduationCap className="h-4 w-4 mr-1" />
                                Grade
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                
                <Button 
                  className="mt-4"
                  onClick={() => toast({
                    title: "Create Lab Assignment",
                    description: `Creating new lab work for ${course.name}`,
                    variant: "default"
                  })}
                >
                  Create New Lab Work
                </Button>
              </div>
            ))}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );

  // Render attendance section
  const renderAttendanceSection = () => {    
    return (
      <Card className="mb-6">
        <CardContent className="p-5">
          <h2 className="text-xl font-bold text-slate-800 mb-4">Attendance Management</h2>
          
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
            <div className="flex items-center gap-4">
              <Select defaultValue="today">
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select date" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="yesterday">Yesterday</SelectItem>
                  <SelectItem value="custom">Custom Date</SelectItem>
                </SelectContent>
              </Select>
              
              <Select defaultValue="1">
                <SelectTrigger className="w-[250px]">
                  <SelectValue placeholder="Select course" />
                </SelectTrigger>
                <SelectContent>
                  {courses.map((course: any) => (
                    <SelectItem key={course.id} value={course.id.toString()}>
                      {course.name} ({course.code})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <Button
              onClick={() => toast({
                title: "Attendance Saved",
                description: "Student attendance has been updated successfully.",
                variant: "default"
              })}
            >
              <Save className="h-4 w-4 mr-2" />
              Save Attendance
            </Button>
          </div>
          
          <div className="mb-6">
            <h3 className="text-lg font-medium text-slate-800 mb-2">Attendance Overview</h3>
            <div className="bg-slate-50 p-4 rounded-lg">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div>
                  <span className="text-sm text-slate-500">Total Students</span>
                  <p className="text-xl font-bold text-slate-800">45</p>
                </div>
                <div>
                  <span className="text-sm text-slate-500">Present Today</span>
                  <p className="text-xl font-bold text-green-600">38</p>
                </div>
                <div>
                  <span className="text-sm text-slate-500">Absent Today</span>
                  <p className="text-xl font-bold text-red-600">7</p>
                </div>
              </div>
              
              <div className="w-full bg-slate-200 rounded-full h-2.5">
                <div className="bg-green-500 h-2.5 rounded-full" style={{ width: '84%' }}></div>
              </div>
              <div className="flex justify-between text-xs mt-1">
                <span>0%</span>
                <span>Attendance: 84%</span>
                <span>100%</span>
              </div>
            </div>
          </div>
          
          {/* Search by Roll Number */}
          <div className="mb-6">
            <div className="flex items-center gap-4">
              <div className="relative flex-grow">
                <Input
                  type="text"
                  placeholder="Search by Roll Number..."
                  value={searchRollNo}
                  onChange={(e) => setSearchRollNo(e.target.value)}
                  className="pl-10"
                />
                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </div>
              </div>
            </div>
            
            {searchRollNo && filteredStudents.length === 0 && (
              <div className="mt-4 text-center text-slate-500">
                No students found with roll number "{searchRollNo}"
              </div>
            )}
            
            {searchRollNo && filteredStudents.length === 1 && (
              <div className="mt-4 bg-slate-50 p-4 rounded-lg">
                <div className="flex items-center gap-4 mb-4">
                  <div className="h-16 w-16 bg-slate-200 rounded-full flex items-center justify-center text-lg font-bold">
                    {filteredStudents[0].firstName.charAt(0)}{filteredStudents[0].lastName.charAt(0)}
                  </div>
                  <div>
                    <h4 className="text-lg font-bold">{filteredStudents[0].firstName} {filteredStudents[0].lastName}</h4>
                    <p className="text-sm text-slate-500">Roll No: S{filteredStudents[0].id}</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div>
                    <span className="text-sm font-medium text-slate-500">Attendance Rate</span>
                    <p className="text-xl font-bold text-slate-800">{Math.round((15 - Math.floor((15 + filteredStudents[0].id) / 5)) / 15 * 100)}%</p>
                  </div>
                  <div>
                    <span className="text-sm font-medium text-slate-500">Classes Attended</span>
                    <p className="text-xl font-bold text-green-600">{15 - Math.floor((15 + filteredStudents[0].id) / 5)}/15</p>
                  </div>
                  <div>
                    <span className="text-sm font-medium text-slate-500">Last Attendance</span>
                    <p className="text-md font-medium">Today (Present)</p>
                  </div>
                </div>
                
                <div className="mb-4">
                  <h5 className="text-md font-medium mb-2">Attendance History</h5>
                  <div className="flex flex-wrap gap-2">
                    {Array.from({ length: 15 }, (_, i) => {
                      const isPresent = (i + filteredStudents[0].id) % 5 !== 0;
                      return (
                        <div 
                          key={i}
                          className={`w-8 h-8 rounded-md flex items-center justify-center text-xs font-medium
                            ${isPresent ? 'bg-green-100 text-green-800 border border-green-200' : 'bg-red-100 text-red-800 border border-red-200'}`}
                        >
                          {i + 1}
                        </div>
                      );
                    })}
                  </div>
                </div>
                
                <div>
                  <h5 className="text-md font-medium mb-2">Assignment Completion</h5>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-indigo-50 p-3 rounded-lg">
                      <div className="text-center mb-1">
                        <span className="text-xs text-slate-500">Assignment 1</span>
                      </div>
                      <div className="flex justify-center">
                        <CheckCircle className="h-6 w-6 text-green-500" />
                      </div>
                    </div>
                    <div className="bg-indigo-50 p-3 rounded-lg">
                      <div className="text-center mb-1">
                        <span className="text-xs text-slate-500">Assignment 2</span>
                      </div>
                      <div className="flex justify-center">
                        {filteredStudents[0].id % 2 === 0 ? (
                          <CheckCircle className="h-6 w-6 text-green-500" />
                        ) : (
                          <XCircle className="h-6 w-6 text-red-500" />
                        )}
                      </div>
                    </div>
                    <div className="bg-indigo-50 p-3 rounded-lg">
                      <div className="text-center mb-1">
                        <span className="text-xs text-slate-500">Assignment 3</span>
                      </div>
                      <div className="flex justify-center">
                        {filteredStudents[0].id % 3 === 0 ? (
                          <CheckCircle className="h-6 w-6 text-green-500" />
                        ) : (
                          <XCircle className="h-6 w-6 text-red-500" />
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
          
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[250px]">Student</TableHead>
                  {Array.from({ length: 15 }, (_, i) => (
                    <TableHead key={i} className="text-center">L{i + 1}</TableHead>
                  ))}
                  <TableHead className="text-center">Total</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(searchRollNo ? filteredStudents : students.slice(0, 8)).map((student: any, index: number) => (
                  <TableRow key={student.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center">
                        <div className="mr-2 h-8 w-8 bg-slate-200 rounded-full flex items-center justify-center">
                          {student.firstName.charAt(0)}{student.lastName.charAt(0)}
                        </div>
                        <div>
                          <div className="text-sm font-medium">{student.firstName} {student.lastName}</div>
                          <div className="text-xs text-slate-500">ID: S{student.id}</div>
                        </div>
                      </div>
                    </TableCell>
                    
                    {Array.from({ length: 15 }, (_, i) => {
                      // Generate a pseudo-random attendance pattern for demo
                      const isPresent = (i + student.id) % 5 !== 0;
                      
                      return (
                        <TableCell key={i} className="text-center">
                          <Checkbox 
                            defaultChecked={isPresent} 
                            onCheckedChange={(checked) => toast({
                              title: checked ? "Marked Present" : "Marked Absent",
                              description: `${student.firstName} ${student.lastName} marked ${checked ? 'present' : 'absent'} for Lecture ${i + 1}`,
                              variant: "default"
                            })}
                          />
                        </TableCell>
                      );
                    })}
                    
                    <TableCell className="text-center font-medium">
                      {/* Calculate a percentage based on our pseudo-random pattern */}
                      {Math.round((15 - Math.floor((15 + student.id) / 5)) / 15 * 100)}%
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          
          <div className="mt-6 flex justify-between">
            <Button variant="outline">
              <Calendar className="h-4 w-4 mr-2" />
              View Schedule
            </Button>
            
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export Report
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  };

  // Render grades section
  const renderGradesSection = () => (
    <Card className="mb-6">
      <CardContent className="p-5">
        <h2 className="text-xl font-bold text-slate-800 mb-4">Grade Management</h2>
        
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <div className="flex items-center gap-4">
            <Select defaultValue="midterm">
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select exam" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="assignments">Assignments</SelectItem>
                <SelectItem value="midterm">Midterm</SelectItem>
                <SelectItem value="final">Final</SelectItem>
              </SelectContent>
            </Select>
            
            <Select defaultValue="1">
              <SelectTrigger className="w-[250px]">
                <SelectValue placeholder="Select course" />
              </SelectTrigger>
              <SelectContent>
                {courses.map((course: any) => (
                  <SelectItem key={course.id} value={course.id.toString()}>
                    {course.name} ({course.code})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <Button
            onClick={() => toast({
              title: "Grades Saved",
              description: "Student grades have been updated successfully.",
              variant: "default"
            })}
          >
            <Save className="h-4 w-4 mr-2" />
            Save Grades
          </Button>
        </div>
        
        <div className="mb-6">
          <h3 className="text-lg font-medium text-slate-800 mb-2">Course: Database Systems (CSE-301)</h3>
          <h4 className="text-md text-slate-600 mb-4">Midterm Examination</h4>
        </div>
        
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[250px]">Student</TableHead>
                <TableHead className="text-center">Internal (20)</TableHead>
                <TableHead className="text-center">External (20)</TableHead>
                <TableHead className="text-center">Practical (10)</TableHead>
                <TableHead className="text-center">Total (50)</TableHead>
                <TableHead className="text-center">Grade</TableHead>
                <TableHead className="text-center">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {students.slice(0, 8).map((student: any) => {
                // Generate scores for demo purposes
                const internal = Math.floor(Math.random() * 6) + 15; // 15-20
                const external = Math.floor(Math.random() * 8) + 13; // 13-20
                const practical = Math.floor(Math.random() * 4) + 7; // 7-10
                const total = internal + external + practical;
                
                // Calculate grade
                let grade;
                if (total >= 45) grade = 'A';
                else if (total >= 40) grade = 'B+';
                else if (total >= 35) grade = 'B';
                else if (total >= 30) grade = 'C+';
                else if (total >= 25) grade = 'C';
                else grade = 'F';
                
                return (
                  <TableRow key={student.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center">
                        <div className="mr-2 h-8 w-8 bg-slate-200 rounded-full flex items-center justify-center">
                          {student.firstName.charAt(0)}{student.lastName.charAt(0)}
                        </div>
                        <div>
                          <div className="text-sm font-medium">{student.firstName} {student.lastName}</div>
                          <div className="text-xs text-slate-500">ID: S{student.id}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      <Input 
                        type="number" 
                        className="w-16 text-center mx-auto" 
                        defaultValue={internal} 
                        min={0} 
                        max={20}
                        onChange={() => toast({
                          title: "Grade Updated",
                          description: `Internal mark updated for ${student.firstName} ${student.lastName}`,
                          variant: "default"
                        })}
                      />
                    </TableCell>
                    <TableCell className="text-center">
                      <Input 
                        type="number" 
                        className="w-16 text-center mx-auto" 
                        defaultValue={external} 
                        min={0} 
                        max={20}
                        onChange={() => toast({
                          title: "Grade Updated",
                          description: `External mark updated for ${student.firstName} ${student.lastName}`,
                          variant: "default"
                        })}
                      />
                    </TableCell>
                    <TableCell className="text-center">
                      <Input 
                        type="number" 
                        className="w-16 text-center mx-auto" 
                        defaultValue={practical} 
                        min={0} 
                        max={10}
                        onChange={() => toast({
                          title: "Grade Updated",
                          description: `Practical mark updated for ${student.firstName} ${student.lastName}`,
                          variant: "default"
                        })}
                      />
                    </TableCell>
                    <TableCell className="text-center font-medium">{total}/50</TableCell>
                    <TableCell className="text-center">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                        ${grade === 'A' ? 'bg-green-100 text-green-800' : 
                          grade === 'B+' || grade === 'B' ? 'bg-blue-100 text-blue-800' :
                          grade === 'C+' || grade === 'C' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-red-100 text-red-800'}`}>
                        {grade}
                      </span>
                    </TableCell>
                    <TableCell className="text-center">
                      <Button variant="outline" size="sm"
                        onClick={() => toast({
                          title: "Grading Details",
                          description: `Viewing detailed grading for ${student.firstName} ${student.lastName}`,
                          variant: "default"
                        })}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
        
        <div className="mt-6">
          <h3 className="text-lg font-medium text-slate-800 mb-4">Class Performance</h3>
          <div className="bg-slate-50 p-4 rounded-lg">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <span className="text-sm text-slate-500">Class Average</span>
                <p className="text-xl font-bold text-slate-800">38/50</p>
              </div>
              <div>
                <span className="text-sm text-slate-500">Highest Score</span>
                <p className="text-xl font-bold text-green-600">48/50</p>
              </div>
              <div>
                <span className="text-sm text-slate-500">Lowest Score</span>
                <p className="text-xl font-bold text-red-600">22/50</p>
              </div>
              <div>
                <span className="text-sm text-slate-500">Pass Rate</span>
                <p className="text-xl font-bold text-blue-600">92%</p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  // Render announcements section
  const renderAnnouncementsSection = () => (
    <Card className="mb-6">
      <CardContent className="p-5">
        <h2 className="text-xl font-bold text-slate-800 mb-4">Announcements</h2>
        
        <div className="mb-6">
          <Button
            onClick={() => toast({
              title: "New Announcement",
              description: "Creating a new announcement",
              variant: "default"
            })}
          >
            Create New Announcement
          </Button>
        </div>
        
        <div className="space-y-4">
          {Array.from({ length: 3 }, (_, i) => (
            <Card key={i} className="border border-slate-200">
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-lg font-medium text-slate-800">
                    {i === 0 ? 'Midterm Examination Schedule' : 
                     i === 1 ? 'Assignment Deadline Extended' : 
                     'Guest Lecture Announcement'}
                  </h3>
                  <span className="text-xs text-slate-500">
                    {new Date(2025, 2, 20 - i * 5).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  </span>
                </div>
                
                <p className="text-slate-600 mb-3">
                  {i === 0 ? 'The midterm examinations for all courses will be held from April 10 to April 15. The detailed schedule is now available on the examination portal.' : 
                   i === 1 ? 'Due to the upcoming university event, the deadline for Database Systems Assignment 2 has been extended to April 5.' : 
                   'There will be a guest lecture by Dr. Jane Smith from Tech University on "Advanced Database Concepts" on April 8 at 2:00 PM in Lecture Hall 102.'}
                </p>
                
                <div className="flex justify-between items-center">
                  <span className="text-xs font-medium inline-flex items-center px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800">
                    {i === 0 ? 'All Courses' : 
                     i === 1 ? 'Database Systems' : 
                     'Departmental'}
                  </span>
                  
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm"
                      onClick={() => toast({
                        title: "Edit Announcement",
                        description: "Editing announcement",
                        variant: "default"
                      })}
                    >
                      <Edit className="h-4 w-4 mr-1" />
                      Edit
                    </Button>
                    
                    <Button variant="outline" size="sm"
                      onClick={() => toast({
                        title: "Delete Announcement",
                        description: "Announcement deleted",
                        variant: "default"
                      })}
                    >
                      <X className="h-4 w-4 mr-1" />
                      Delete
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </CardContent>
    </Card>
  );

  // Dashboard overview section
  const renderDashboardSection = () => (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-800">Teacher Dashboard</h1>
        <p className="text-slate-500">Welcome, {user.firstName} {user.lastName}!</p>
      </div>
      
      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-slate-500">My Courses</p>
                <h3 className="text-2xl font-bold">{courses.length}</h3>
              </div>
              <div className="bg-blue-100 p-2 rounded-md">
                <BookCopy className="h-5 w-5 text-blue-600" />
              </div>
            </div>
            <div className="mt-4 text-xs text-slate-500">
              <span className="text-green-500">● </span>
              {theoryCourses.length} Theory, {labCourses.length} Lab
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-slate-500">Total Students</p>
                <h3 className="text-2xl font-bold">{students.length}</h3>
              </div>
              <div className="bg-indigo-100 p-2 rounded-md">
                <UsersRound className="h-5 w-5 text-indigo-600" />
              </div>
            </div>
            <div className="mt-4 text-xs text-slate-500">
              <span className="text-green-500">↑ </span>
              5% increase from last term
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-slate-500">Assignments</p>
                <h3 className="text-2xl font-bold">{assignments.length}</h3>
              </div>
              <div className="bg-emerald-100 p-2 rounded-md">
                <ClipboardList className="h-5 w-5 text-emerald-600" />
              </div>
            </div>
            <div className="mt-4 text-xs text-slate-500">
              <span className="text-amber-500">● </span>
              {Math.round(assignments.length * 0.65)} Graded
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-slate-500">Avg. Attendance</p>
                <h3 className="text-2xl font-bold">78%</h3>
              </div>
              <div className="bg-rose-100 p-2 rounded-md">
                <Clock className="h-5 w-5 text-rose-600" />
              </div>
            </div>
            <div className="mt-4 text-xs text-slate-500">
              <span className="text-red-500">↓ </span>
              3% decrease from last week
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Recent Activity and Alerts */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Array.from({ length: 5 }, (_, i) => (
                <div key={i} className="flex gap-3 pb-3 border-b border-slate-100 last:border-0">
                  <div className={`w-9 h-9 rounded-full flex items-center justify-center
                    ${i % 3 === 0 ? 'bg-blue-100 text-blue-600' : 
                      i % 3 === 1 ? 'bg-green-100 text-green-600' : 'bg-amber-100 text-amber-600'}`}>
                    {i % 3 === 0 ? <Clock className="h-4 w-4" /> : 
                      i % 3 === 1 ? <CheckCircle className="h-4 w-4" /> : 
                      <ClipboardList className="h-4 w-4" />}
                  </div>
                  <div>
                    <p className="text-sm font-medium">
                      {i % 3 === 0 ? 'Updated attendance for Database Systems' : 
                        i % 3 === 1 ? 'Graded 5 assignments for Web Development' : 
                        'Added a new assignment for Machine Learning'}
                    </p>
                    <p className="text-xs text-slate-500">
                      {i === 0 ? 'Just now' : 
                        i === 1 ? '2 hours ago' : 
                        i === 2 ? 'Yesterday at 4:30 PM' :
                        i === 3 ? 'Yesterday at 1:15 PM' : '2 days ago'}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Alerts & Notifications</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="bg-red-50 border-l-4 border-red-500 p-3 rounded">
                <div className="flex items-center gap-2 text-red-800">
                  <AlertTriangle className="h-4 w-4" />
                  <p className="text-sm font-medium">7 Students Below 75% Attendance</p>
                </div>
                <p className="text-xs text-red-700 mt-1">In Database Systems Course</p>
              </div>
              
              <div className="bg-amber-50 border-l-4 border-amber-500 p-3 rounded">
                <div className="flex items-center gap-2 text-amber-800">
                  <AlertTriangle className="h-4 w-4" />
                  <p className="text-sm font-medium">12 Assignment Submissions Pending Review</p>
                </div>
                <p className="text-xs text-amber-700 mt-1">Due by April 2, 2025</p>
              </div>
              
              <div className="bg-blue-50 border-l-4 border-blue-500 p-3 rounded">
                <div className="flex items-center gap-2 text-blue-800">
                  <Bell className="h-4 w-4" />
                  <p className="text-sm font-medium">Mid-Semester Exam Schedule Published</p>
                </div>
                <p className="text-xs text-blue-700 mt-1">Starting from April 10, 2025</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Course Progress */}
      <Card>
        <CardHeader>
          <CardTitle>Course Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-5">
            {courses.slice(0, 3).map((course: any, index: number) => (
              <div key={course.id}>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">{course.name} ({course.code})</span>
                  <span className="text-sm font-medium">{70 + index * 5}%</span>
                </div>
                <Progress value={70 + index * 5} className="h-2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
  
  // Courses and divisions section
  const renderCoursesSection = () => (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-800">Courses & Divisions</h1>
        <p className="text-slate-500">Manage your courses and student divisions</p>
      </div>
      
      <div className="flex items-center justify-between mb-6">
        <Tabs defaultValue="all" className="w-[400px]">
          <TabsList>
            <TabsTrigger value="all">All Courses</TabsTrigger>
            <TabsTrigger value="theory">Theory</TabsTrigger>
            <TabsTrigger value="lab">Lab</TabsTrigger>
          </TabsList>
        </Tabs>
        
        <Button>
          <BookCopy className="h-4 w-4 mr-2" />
          Add New Course
        </Button>
      </div>
      
      <div className="grid grid-cols-1 gap-6">
        {courses.map((course: any) => (
          <Card key={course.id}>
            <CardContent className="p-0">
              <div className={`p-5 ${course.type === 'theory' ? 'bg-indigo-50' : 'bg-blue-50'}`}>
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-lg font-bold text-slate-800">{course.name} ({course.code})</h3>
                    <p className="text-sm text-slate-600">{course.department} | {course.type === 'theory' ? 'Theory Course' : 'Laboratory Course'}</p>
                  </div>
                  <Badge variant={course.type === 'theory' ? 'default' : 'secondary'}>
                    {course.type === 'theory' ? 'Theory' : 'Lab'}
                  </Badge>
                </div>
              </div>
              
              <div className="p-5">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-4">
                  <div>
                    <h4 className="text-sm font-medium text-slate-500 mb-1">Divisions</h4>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="outline">Division A</Badge>
                      <Badge variant="outline">Division B</Badge>
                      {course.id % 2 === 0 && <Badge variant="outline">Division C</Badge>}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-medium text-slate-500 mb-1">Total Students</h4>
                    <p className="text-xl font-bold">{30 + course.id * 5}</p>
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-medium text-slate-500 mb-1">Course Completion</h4>
                    <div className="flex items-center gap-2">
                      <Progress value={60 + course.id * 5} className="flex-1 h-2" />
                      <span className="text-sm font-medium">{60 + course.id * 5}%</span>
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-4">
                  <Card className="p-3 bg-slate-50">
                    <div className="text-sm font-medium text-center">Classes Conducted</div>
                    <div className="text-lg font-bold text-center">{8 + course.id}</div>
                  </Card>
                  
                  <Card className="p-3 bg-slate-50">
                    <div className="text-sm font-medium text-center">Avg. Attendance</div>
                    <div className="text-lg font-bold text-center">{80 - course.id * 2}%</div>
                  </Card>
                  
                  <Card className="p-3 bg-slate-50">
                    <div className="text-sm font-medium text-center">Assignments</div>
                    <div className="text-lg font-bold text-center">{3 + (course.id % 3)}</div>
                  </Card>
                  
                  <Card className="p-3 bg-slate-50">
                    <div className="text-sm font-medium text-center">Avg. Performance</div>
                    <div className="text-lg font-bold text-center">{70 + course.id * 3}%</div>
                  </Card>
                </div>
                
                <div className="flex gap-2 justify-end">
                  <Button variant="outline" size="sm">
                    <UsersRound className="h-4 w-4 mr-1" />
                    Manage Divisions
                  </Button>
                  
                  <Button variant="outline" size="sm">
                    <BarChart className="h-4 w-4 mr-1" />
                    Course Analytics
                  </Button>
                  
                  <Button size="sm">
                    <Clipboard className="h-4 w-4 mr-1" />
                    Course Details
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
  
  // Students section
  const renderStudentsSection = () => (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-800">Student Management</h1>
        <p className="text-slate-500">Search, view, and analyze student performance</p>
      </div>
      
      <Card className="mb-6">
        <CardContent className="p-5">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-grow">
              <Input
                type="text"
                placeholder="Search by name, roll number, or division..."
                value={searchRollNo}
                onChange={(e) => setSearchRollNo(e.target.value)}
                className="pl-10"
              />
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <Search className="h-4 w-4 text-slate-400" />
              </div>
            </div>
            
            <div className="flex gap-2">
              <Select defaultValue="all-div">
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filter by Division" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-div">All Divisions</SelectItem>
                  <SelectItem value="div-a">Division A</SelectItem>
                  <SelectItem value="div-b">Division B</SelectItem>
                  <SelectItem value="div-c">Division C</SelectItem>
                </SelectContent>
              </Select>
              
              <Select defaultValue="all-courses">
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filter by Course" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-courses">All Courses</SelectItem>
                  {courses.map((course: any) => (
                    <SelectItem key={course.id} value={course.id.toString()}>
                      {course.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Button variant="outline" size="icon">
                <ListFilter className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>Roll No</TableHead>
                  <TableHead>Division</TableHead>
                  <TableHead className="text-center">Attendance</TableHead>
                  <TableHead className="text-center">Assignments</TableHead>
                  <TableHead className="text-center">Performance</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStudents.slice(0, 10).map((student: any) => {
                  // Calculate some demo values
                  const attendance = Math.round(70 + Math.random() * 25);
                  const assignments = Math.round(60 + Math.random() * 40);
                  const performance = Math.round(65 + Math.random() * 30);
                  
                  return (
                    <TableRow key={student.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-sm font-medium">
                            {student.firstName.charAt(0)}{student.lastName.charAt(0)}
                          </div>
                          <div>
                            <div className="font-medium">{student.firstName} {student.lastName}</div>
                            <div className="text-xs text-slate-500">{student.department}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>S{student.id}</TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          Division {String.fromCharCode(65 + (student.id % 3))}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        <div className="flex justify-center items-center">
                          <Badge variant={attendance >= 75 ? 'default' : 'destructive'} className="w-14">
                            {attendance}%
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell className="text-center">
                        <div className="flex justify-center items-center">
                          <Badge variant={assignments >= 70 ? 'default' : 'secondary'} className="w-14">
                            {assignments}%
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell className="text-center">
                        <div className="flex justify-center items-center">
                          <Badge variant={
                            performance >= 85 ? 'default' : 
                            performance >= 70 ? 'secondary' : 'outline'
                          } className="w-14">
                            {performance}%
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="outline" size="sm" className="mr-1"
                          onClick={() => toast({
                            title: "Student Profile",
                            description: `Viewing profile for ${student.firstName} ${student.lastName}`,
                            variant: "default"
                          })}
                        >
                          View Profile
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  // Render reports section
  const renderReportsSection = () => (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-800">Reports & Analytics</h1>
        <p className="text-slate-500">Generate and export comprehensive reports</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card className="p-5">
          <div className="flex items-center gap-4 mb-4">
            <div className="bg-blue-100 p-3 rounded-lg">
              <FileSpreadsheet className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <h3 className="font-medium">Attendance Report</h3>
              <p className="text-sm text-slate-500">Daily/weekly attendance statistics</p>
            </div>
          </div>
          <Button className="w-full" variant="outline">Generate Report</Button>
        </Card>
        
        <Card className="p-5">
          <div className="flex items-center gap-4 mb-4">
            <div className="bg-indigo-100 p-3 rounded-lg">
              <Clipboard className="h-6 w-6 text-indigo-600" />
            </div>
            <div>
              <h3 className="font-medium">Assignment Analysis</h3>
              <p className="text-sm text-slate-500">Submission and performance metrics</p>
            </div>
          </div>
          <Button className="w-full" variant="outline">Generate Report</Button>
        </Card>
        
        <Card className="p-5">
          <div className="flex items-center gap-4 mb-4">
            <div className="bg-emerald-100 p-3 rounded-lg">
              <BarChart2 className="h-6 w-6 text-emerald-600" />
            </div>
            <div>
              <h3 className="font-medium">Performance Insights</h3>
              <p className="text-sm text-slate-500">Detailed academic performance</p>
            </div>
          </div>
          <Button className="w-full" variant="outline">Generate Report</Button>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Custom Report Builder</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
            <Select defaultValue="all-courses">
              <SelectTrigger>
                <SelectValue placeholder="Select Course" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all-courses">All Courses</SelectItem>
                {courses.map((course: any) => (
                  <SelectItem key={course.id} value={course.id.toString()}>
                    {course.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select defaultValue="all-div">
              <SelectTrigger>
                <SelectValue placeholder="Select Division" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all-div">All Divisions</SelectItem>
                <SelectItem value="div-a">Division A</SelectItem>
                <SelectItem value="div-b">Division B</SelectItem>
                <SelectItem value="div-c">Division C</SelectItem>
              </SelectContent>
            </Select>
            
            <Select defaultValue="all-metrics">
              <SelectTrigger>
                <SelectValue placeholder="Select Metrics" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all-metrics">All Metrics</SelectItem>
                <SelectItem value="attendance">Attendance</SelectItem>
                <SelectItem value="assignments">Assignments</SelectItem>
                <SelectItem value="exams">Exam Results</SelectItem>
                <SelectItem value="overall">Overall Performance</SelectItem>
              </SelectContent>
            </Select>
            
            <Select defaultValue="march-2025">
              <SelectTrigger>
                <SelectValue placeholder="Select Time Period" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="march-2025">March 2025</SelectItem>
                <SelectItem value="feb-2025">February 2025</SelectItem>
                <SelectItem value="jan-2025">January 2025</SelectItem>
                <SelectItem value="spring-2025">Spring Semester 2025</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex gap-2 justify-end">
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export as PDF
            </Button>
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export as Excel
            </Button>
            <Button>
              <PieChart className="h-4 w-4 mr-2" />
              Generate Report
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
  
  // Render the active section
  const renderActiveSection = () => {
    switch (activeSection) {
      case 'dashboard':
        return renderDashboardSection();
      case 'courses':
        return renderCoursesSection();
      case 'students':
        return renderStudentsSection();
      case 'assignments':
        return renderAssignmentsSection();
      case 'attendance':
        return renderAttendanceSection();
      case 'grades':
        return renderGradesSection();
      case 'reports':
        return renderReportsSection();
      default:
        return renderDashboardSection();
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Top Navigation Bar */}
      <div className="fixed top-0 left-0 right-0 bg-white border-b z-10 p-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <BookOpen className="text-indigo-600 h-6 w-6 mr-2" />
            <h1 className="text-lg font-bold text-indigo-700">Teacher Dashboard</h1>
          </div>

          <div className="flex items-center space-x-3">
            <div className="hidden md:flex items-center mr-4">
              <div className="text-sm font-medium">
                <span className="text-slate-500">Term:</span> Spring 2025
              </div>
              <Separator orientation="vertical" className="h-6 mx-3" />
              <div className="text-sm font-medium">
                <span className="text-slate-500">Dept:</span> {user.department}
              </div>
            </div>
            
            <div className="flex items-center bg-indigo-50 rounded-full px-3 py-1">
              <User className="h-4 w-4 text-indigo-600 mr-2" />
              <span className="text-sm font-medium text-indigo-700">{user.firstName}</span>
            </div>
            
            <Button 
              variant="outline" 
              size="sm"
              className="text-red-500 border-red-200 hover:bg-red-50"
              onClick={onLogout}
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="p-4 pt-20">
        {/* Navigation Buttons - Desktop View */}
        <div className="hidden md:block mb-6">
          <div className="bg-white rounded-lg shadow-sm p-1.5 flex justify-center">
            <div className="flex gap-2">
              {navigationSections.map((section) => (
                <Button 
                  key={section.id}
                  variant={activeSection === section.id ? 'default' : 'ghost'} 
                  size="sm"
                  className="px-4 py-2"
                  onClick={() => setActiveSection(section.id)}
                >
                  <span className="mr-2">{section.icon}</span>
                  {section.label}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Mobile Navigation Buttons - Scrollable */}
        <div className="md:hidden">
          <div className="overflow-x-auto pb-4 mb-6 -mx-4 px-4">
            <div className="flex gap-2 w-max">
              {navigationSections.map((section) => (
                <Button 
                  key={section.id}
                  variant={activeSection === section.id ? 'default' : 'outline'} 
                  size="sm"
                  className="px-3 py-1 h-auto whitespace-nowrap"
                  onClick={() => setActiveSection(section.id)}
                >
                  <span className="mr-1">{section.icon}</span>
                  {section.id.charAt(0).toUpperCase() + section.id.slice(1)}
                </Button>
              ))}
            </div>
          </div>
        </div>
        
        {renderActiveSection()}
      </div>
    </div>
  );
};

export default FacultyDashboard;
