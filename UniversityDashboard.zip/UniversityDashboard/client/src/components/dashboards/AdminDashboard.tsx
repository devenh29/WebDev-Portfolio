import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Link } from 'wouter';
import { 
  UserPlus, UsersRound, BookOpen, CalendarDays, Bell,
  LineChart, Settings, PlusCircle, CheckCircle, ArrowUpCircle,
  BarChart
} from 'lucide-react';

import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { User } from '@shared/schema';

interface AdminDashboardProps {
  user: User;
  onLogout?: () => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ user, onLogout }) => {
  // Fetch users by role
  const { data: students = [] } = useQuery<any[]>({
    queryKey: ['/api/users'],
    queryFn: async ({ queryKey }) => {
      const response = await fetch(`${queryKey[0]}?role=student`);
      if (!response.ok) throw new Error('Failed to fetch students');
      return response.json();
    }
  });

  const { data: faculty = [] } = useQuery<any[]>({
    queryKey: ['/api/users'],
    queryFn: async ({ queryKey }) => {
      const response = await fetch(`${queryKey[0]}?role=faculty`);
      if (!response.ok) throw new Error('Failed to fetch faculty');
      return response.json();
    }
  });

  // Fetch courses
  const { data: courses = [] } = useQuery<any[]>({
    queryKey: ['/api/courses'],
  });

  // Dummy departments for demonstration
  const departments = [
    { name: 'Computer Science', students: 463, faculty: 26, courses: 32, status: 'Active' },
    { name: 'Electrical Engineering', students: 375, faculty: 21, courses: 28, status: 'Active' },
    { name: 'Business Administration', students: 521, faculty: 32, courses: 36, status: 'Active' },
    { name: 'Mechanical Engineering', students: 312, faculty: 18, courses: 22, status: 'Active' }
  ];

  // Recent activities for demonstration
  const activities = [
    { 
      type: 'success', 
      title: 'New course added', 
      description: 'Advanced Machine Learning (CSE-512) has been added to the curriculum.',
      time: '2 hours ago',
      by: 'Admin'
    },
    {
      type: 'warning',
      title: 'System maintenance scheduled',
      description: 'System maintenance is scheduled for October 15, 2023, 1:00 AM - 3:00 AM.',
      time: '5 hours ago',
      by: 'System'
    },
    {
      type: 'info',
      title: 'New faculty member added',
      description: 'Dr. Emily Parker has been added to the Physics department.',
      time: 'Yesterday',
      by: 'HR Admin'
    },
    {
      type: 'info',
      title: 'Announcement published',
      description: 'Mid-term examination schedule has been published for all departments.',
      time: 'Yesterday',
      by: 'Academic Admin'
    }
  ];

  return (
    <div>
      <div className="mb-6 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 font-heading">Admin Dashboard</h1>
          <p className="text-slate-500">System overview and management</p>
        </div>
        
        {onLogout && (
          <Button 
            onClick={onLogout}
            variant="outline"
            className="flex items-center gap-2"
          >
            <span>Logout</span>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
              <polyline points="16 17 21 12 16 7" />
              <line x1="21" y1="12" x2="9" y2="12" />
            </svg>
          </Button>
        )}
      </div>
      
      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-slate-500 text-sm mb-1">Total Students</div>
                <div className="text-2xl font-bold text-slate-800">{students.length || 2845}</div>
              </div>
              <div className="p-3 bg-indigo-100 rounded-full">
                <UsersRound className="h-6 w-6 text-indigo-600" />
              </div>
            </div>
            <div className="flex items-center text-xs text-green-600 mt-2">
              <ArrowUpCircle className="h-3 w-3 mr-1" />
              <span>5.2% from last year</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-slate-500 text-sm mb-1">Faculty Members</div>
                <div className="text-2xl font-bold text-slate-800">{faculty.length || 126}</div>
              </div>
              <div className="p-3 bg-blue-100 rounded-full">
                <UsersRound className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <div className="flex items-center text-xs text-green-600 mt-2">
              <ArrowUpCircle className="h-3 w-3 mr-1" />
              <span>3.1% from last year</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-slate-500 text-sm mb-1">Active Courses</div>
                <div className="text-2xl font-bold text-slate-800">{Array.isArray(courses) ? courses.length : 187}</div>
              </div>
              <div className="p-3 bg-yellow-100 rounded-full">
                <BookOpen className="h-6 w-6 text-yellow-600" />
              </div>
            </div>
            <div className="flex items-center text-xs text-slate-500 mt-2">
              <span>Current semester</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-slate-500 text-sm mb-1">Departments</div>
                <div className="text-2xl font-bold text-slate-800">12</div>
              </div>
              <div className="p-3 bg-green-100 rounded-full">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                </svg>
              </div>
            </div>
            <div className="flex items-center text-xs text-green-600 mt-2">
              <PlusCircle className="h-3 w-3 mr-1" />
              <span>1 new this year</span>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Department & Management */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Department Stats */}
        <Card className="lg:col-span-2">
          <CardContent className="p-5">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-medium text-slate-800">Department Statistics</h2>
              <select className="text-sm border border-slate-300 rounded-md px-2 py-1 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent">
                <option>Fall 2023</option>
                <option>Spring 2023</option>
              </select>
            </div>
            
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-slate-50">
                  <TableRow>
                    <TableHead>Department</TableHead>
                    <TableHead>Students</TableHead>
                    <TableHead>Faculty</TableHead>
                    <TableHead>Courses</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {departments.map((department, index) => (
                    <TableRow key={index}>
                      <TableCell>
                        <div className="text-sm font-medium text-slate-900">{department.name}</div>
                      </TableCell>
                      <TableCell className="text-sm text-slate-500">{department.students}</TableCell>
                      <TableCell className="text-sm text-slate-500">{department.faculty}</TableCell>
                      <TableCell className="text-sm text-slate-500">{department.courses}</TableCell>
                      <TableCell>
                        <Badge variant="success">{department.status}</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
        
        {/* Quick Actions */}
        <Card>
          <CardContent className="p-5">
            <h2 className="text-lg font-medium text-slate-800 mb-4">Management</h2>
            
            <div className="space-y-4">
              <motion.button
                whileHover={{ x: 5 }}
                whileTap={{ scale: 0.98 }}
                className="btn-primary w-full justify-start bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors duration-300 flex items-center gap-2"
              >
                <UserPlus className="h-5 w-5" />
                <span>Add New User</span>
              </motion.button>
              
              <motion.button
                whileHover={{ x: 5 }}
                whileTap={{ scale: 0.98 }}
                className="btn-primary w-full justify-start bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors duration-300 flex items-center gap-2"
              >
                <UsersRound className="h-5 w-5" />
                <span>Create Class</span>
              </motion.button>
              
              <motion.button
                whileHover={{ x: 5 }}
                whileTap={{ scale: 0.98 }}
                className="btn-primary w-full justify-start bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors duration-300 flex items-center gap-2"
              >
                <PlusCircle className="h-5 w-5" />
                <span>Add New Course</span>
              </motion.button>
              
              <motion.button
                whileHover={{ x: 5 }}
                whileTap={{ scale: 0.98 }}
                className="btn-primary w-full justify-start bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors duration-300 flex items-center gap-2"
              >
                <Bell className="h-5 w-5" />
                <span>Post Announcement</span>
              </motion.button>
              
              <motion.button
                whileHover={{ x: 5 }}
                whileTap={{ scale: 0.98 }}
                className="btn-secondary w-full justify-start bg-white border border-slate-300 text-slate-700 px-4 py-2 rounded-md hover:bg-slate-50 transition-colors duration-300 flex items-center gap-2"
              >
                <BarChart className="h-5 w-5" />
                <span>Generate Reports</span>
              </motion.button>
              
              <motion.button
                whileHover={{ x: 5 }}
                whileTap={{ scale: 0.98 }}
                className="btn-secondary w-full justify-start bg-white border border-slate-300 text-slate-700 px-4 py-2 rounded-md hover:bg-slate-50 transition-colors duration-300 flex items-center gap-2"
              >
                <Settings className="h-5 w-5" />
                <span>System Settings</span>
              </motion.button>
            </div>
            
            <div className="mt-6 bg-slate-50 p-4 rounded-lg">
              <h3 className="text-sm font-medium text-slate-800 mb-2">System Status</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span>Server Load</span>
                  <span className="font-medium text-green-600">32%</span>
                </div>
                <div className="w-full bg-slate-200 rounded-full h-1.5">
                  <div className="bg-green-500 h-1.5 rounded-full" style={{ width: '32%' }}></div>
                </div>
                
                <div className="flex justify-between text-xs">
                  <span>Database</span>
                  <span className="font-medium text-green-600">Healthy</span>
                </div>
                <div className="w-full bg-slate-200 rounded-full h-1.5">
                  <div className="bg-green-500 h-1.5 rounded-full" style={{ width: '100%' }}></div>
                </div>
                
                <div className="flex justify-between text-xs">
                  <span>Storage</span>
                  <span className="font-medium text-yellow-600">68%</span>
                </div>
                <div className="w-full bg-slate-200 rounded-full h-1.5">
                  <div className="bg-yellow-500 h-1.5 rounded-full" style={{ width: '68%' }}></div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Recent Activities & Calendar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Recent Activities */}
        <Card className="lg:col-span-2">
          <CardContent className="p-5">
            <h2 className="text-lg font-medium text-slate-800 mb-4">Recent Activities</h2>
            
            <div className="relative pl-8 space-y-6 before:absolute before:top-0 before:bottom-0 before:left-4 before:w-0.5 before:bg-slate-200">
              {activities.map((activity, index) => (
                <div key={index} className="relative">
                  <div className={`absolute -left-8 mt-1.5 w-6 h-6 rounded-full ${
                    activity.type === 'success' 
                      ? 'bg-green-100' 
                      : activity.type === 'warning' 
                        ? 'bg-yellow-100' 
                        : 'bg-indigo-100'
                  } flex items-center justify-center`}>
                    {activity.type === 'success' ? (
                      <CheckCircle className="h-4 w-4 text-green-600" />
                    ) : activity.type === 'warning' ? (
                      <Bell className="h-4 w-4 text-yellow-600" />
                    ) : (
                      <UserPlus className="h-4 w-4 text-indigo-600" />
                    )}
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-slate-800">{activity.title}</h3>
                    <p className="text-sm text-slate-600 mt-0.5">{activity.description}</p>
                    <p className="text-xs text-slate-500 mt-1">{activity.time} by {activity.by}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        
        {/* Calendar */}
        <Card>
          <CardContent className="p-5">
            <h2 className="text-lg font-medium text-slate-800 mb-4">Academic Calendar</h2>
            
            <div className="text-center mb-4">
              <h3 className="text-md font-medium text-slate-800">October 2023</h3>
            </div>
            
            <div className="grid grid-cols-7 gap-1 text-center text-xs mb-2">
              <div className="text-slate-500">Su</div>
              <div className="text-slate-500">Mo</div>
              <div className="text-slate-500">Tu</div>
              <div className="text-slate-500">We</div>
              <div className="text-slate-500">Th</div>
              <div className="text-slate-500">Fr</div>
              <div className="text-slate-500">Sa</div>
            </div>
            
            <div className="grid grid-cols-7 gap-1 text-center">
              <div className="text-slate-400 py-1">24</div>
              <div className="text-slate-400 py-1">25</div>
              <div className="text-slate-400 py-1">26</div>
              <div className="text-slate-400 py-1">27</div>
              <div className="text-slate-400 py-1">28</div>
              <div className="text-slate-400 py-1">29</div>
              <div className="text-slate-400 py-1">30</div>
              
              <div className="py-1">1</div>
              <div className="py-1">2</div>
              <div className="py-1">3</div>
              <div className="py-1">4</div>
              <div className="py-1">5</div>
              <div className="py-1 font-medium text-indigo-600 rounded-full bg-indigo-50">6</div>
              <div className="py-1">7</div>
              
              <div className="py-1">8</div>
              <div className="py-1">9</div>
              <div className="py-1">10</div>
              <div className="py-1">11</div>
              <div className="py-1">12</div>
              <div className="py-1">13</div>
              <div className="py-1">14</div>
              
              <div className="py-1 font-medium text-yellow-600 rounded-full bg-yellow-50">15</div>
              <div className="py-1 font-medium text-red-600 rounded-full bg-red-50">16</div>
              <div className="py-1 font-medium text-red-600 rounded-full bg-red-50">17</div>
              <div className="py-1 font-medium text-red-600 rounded-full bg-red-50">18</div>
              <div className="py-1 font-medium text-red-600 rounded-full bg-red-50">19</div>
              <div className="py-1 font-medium text-red-600 rounded-full bg-red-50">20</div>
              <div className="py-1 font-medium text-red-600 rounded-full bg-red-50">21</div>
            </div>
            
            <div className="mt-4 space-y-2">
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-indigo-500 mr-2"></div>
                <span className="text-xs text-slate-600">Today</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-yellow-500 mr-2"></div>
                <span className="text-xs text-slate-600">System Maintenance</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
                <span className="text-xs text-slate-600">Mid-term Examinations</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AdminDashboard;
