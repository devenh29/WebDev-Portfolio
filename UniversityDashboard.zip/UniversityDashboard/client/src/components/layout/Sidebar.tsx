import React from 'react';
import { Link, useLocation } from 'wouter';
import { motion } from 'framer-motion';
import { 
  LayoutDashboard, BookOpen, CalendarClock, Award, Bell, 
  Clock, User, LogOut, Users, File, BookMarked, Settings,
  CalendarDays, LineChart, Activity
} from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import { User as UserType } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';

interface SidebarProps {
  user: UserType;
  onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ user, onLogout }) => {
  const [location] = useLocation();

  const handleLogout = async () => {
    try {
      await apiRequest('POST', '/api/auth/logout', {});
      onLogout();
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const isActive = (path: string) => {
    return location === path;
  };

  const renderNavItems = () => {
    const commonItems = [
      { icon: <User size={20} />, label: 'Profile', path: '/profile' },
      { icon: <Bell size={20} />, label: 'Announcements', path: '/announcements' },
    ];

    const studentItems = [
      { icon: <LayoutDashboard size={20} />, label: 'Dashboard', path: '/dashboard' },
    ];

    const facultyItems = [
      { icon: <LayoutDashboard size={20} />, label: 'Dashboard', path: '/dashboard' },
      { icon: <BookOpen size={20} />, label: 'Assignments', path: '/assignments' },
      { icon: <CalendarClock size={20} />, label: 'Attendance', path: '/attendance' },
      { icon: <Award size={20} />, label: 'Grading', path: '/grading' },
      { icon: <Users size={20} />, label: 'My Students', path: '/students' },
      ...commonItems
    ];

    const adminItems = [
      { icon: <LayoutDashboard size={20} />, label: 'Dashboard', path: '/dashboard' },
      { icon: <Users size={20} />, label: 'Students', path: '/students' },
      { icon: <User size={20} />, label: 'Faculty', path: '/faculty' },
      { icon: <BookMarked size={20} />, label: 'Courses', path: '/courses' },
      { icon: <CalendarDays size={20} />, label: 'Timetables', path: '/timetables' },
      { icon: <Bell size={20} />, label: 'Announcements', path: '/announcements' },
      { icon: <LineChart size={20} />, label: 'Reports', path: '/reports' },
      { icon: <Settings size={20} />, label: 'Settings', path: '/settings' }
    ];

    let navItems;
    switch (user.role) {
      case 'student':
        navItems = studentItems;
        break;
      case 'faculty':
        navItems = facultyItems;
        break;
      case 'admin':
        navItems = adminItems;
        break;
      default:
        navItems = studentItems;
    }

    return (
      <>
        {navItems.map((item, index) => (
          <li key={index}>
            <Link href={item.path} className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-md transition-colors duration-300 text-slate-600 hover:bg-slate-100",
                isActive(item.path) && "bg-indigo-50 text-indigo-700 font-medium"
              )}>
                {item.icon}
                <span>{item.label}</span>
            </Link>
          </li>
        ))}
      </>
    );
  };

  return (
    <div className="w-64 hidden md:block bg-white border-r border-slate-200 transition-all duration-300">
      <div className="h-full px-3 py-6 overflow-y-auto">
        <div className="flex items-center p-2 mb-6">
          <Avatar className="w-14 h-14 rounded-full mr-3">
            <AvatarImage src={user.profileImage} alt={`${user.firstName} ${user.lastName}`} />
            <AvatarFallback>{user.firstName.charAt(0)}{user.lastName.charAt(0)}</AvatarFallback>
          </Avatar>
          <div>
            <div className="text-xs font-medium text-indigo-600 uppercase">
              {user.role === 'student' ? user.program : user.role === 'faculty' ? user.department : 'System'}
            </div>
            <div className="text-sm font-medium text-slate-900">{user.firstName} {user.lastName}</div>
            <div className="text-xs text-slate-500">
              {user.role === 'student' 
                ? `Semester ${user.semester}` 
                : user.role === 'faculty' 
                  ? 'Associate Professor' 
                  : 'Administrator'}
            </div>
          </div>
        </div>
        <ul className="space-y-1">
          {renderNavItems()}
          <li className="border-t border-slate-200 mt-6 pt-4">
            <motion.button
              whileHover={{ x: 5 }}
              onClick={handleLogout}
              className="flex w-full items-center gap-3 px-4 py-3 rounded-md transition-colors duration-300 text-red-500 hover:bg-red-50"
            >
              <LogOut size={20} />
              <span>Logout</span>
            </motion.button>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Sidebar;
