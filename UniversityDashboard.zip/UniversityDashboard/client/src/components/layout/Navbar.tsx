import React from 'react';
import { Bell, ChevronDown } from 'lucide-react';
import { motion } from 'framer-motion';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { User } from '@shared/schema';

interface NavbarProps {
  user: User;
}

const Navbar: React.FC<NavbarProps> = ({ user }) => {
  return (
    <nav className="bg-white border-b border-slate-200 fixed top-0 left-0 right-0 z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <h1 className="text-xl font-bold text-indigo-600 font-heading">UniManage</h1>
            </div>
          </div>
          <div className="flex items-center">
            <motion.button 
              className="bg-slate-100 p-1 rounded-full text-slate-600 hover:text-slate-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 mr-3"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Bell className="h-6 w-6" />
            </motion.button>
            <div className="ml-3 relative">
              <div className="flex items-center gap-3">
                <div className="font-medium text-right">
                  <div className="text-sm text-slate-900">{user.firstName} {user.lastName}</div>
                  <div className="text-xs text-slate-500">ID: {user.id}</div>
                </div>
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user.profileImage} alt={`${user.firstName} ${user.lastName}`} />
                  <AvatarFallback>{user.firstName.charAt(0)}{user.lastName.charAt(0)}</AvatarFallback>
                </Avatar>
              </div>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
