import React from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Code, Upload } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Assignment } from '@shared/schema';
import { formatDate, getDaysLeft } from '@/lib/utils';

interface AssignmentCardProps {
  assignment: Assignment;
  courseName: string;
  assignmentType: string;
  onClick?: () => void;
  onUpload?: (assignmentId: number) => void;
}

const AssignmentCard: React.FC<AssignmentCardProps> = ({
  assignment,
  courseName,
  assignmentType,
  onClick,
  onUpload
}) => {
  const daysLeftInfo = getDaysLeft(assignment.dueDate);
  
  const handleUploadClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onUpload) {
      onUpload(assignment.id);
    }
  };
  
  return (
    <motion.div 
      className="flex items-start p-3 rounded-md hover:bg-slate-50 transition-colors cursor-pointer"
      whileHover={{ x: 5 }}
      onClick={onClick}
    >
      <div className="mr-3">
        {assignment.assignmentType === 'theory' ? (
          <BookOpen className="text-yellow-500" />
        ) : (
          <Code className="text-indigo-500" />
        )}
      </div>
      <div className="flex-1">
        <div className="flex justify-between mb-1">
          <div className="flex items-center gap-2">
            <h3 className="font-medium text-slate-800">{assignment.title}</h3>
            {!assignment.submitted && (
              <Button 
                size="sm" 
                variant="outline" 
                className="h-7 px-2 py-1 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 border-indigo-200"
                onClick={handleUploadClick}
              >
                <Upload className="h-3 w-3 mr-1" />
                Upload
              </Button>
            )}
          </div>
          <Badge className={daysLeftInfo.color}>{daysLeftInfo.text}</Badge>
        </div>
        <p className="text-sm text-slate-600 mb-1">{assignment.description}</p>
        <div className="flex justify-between text-xs text-slate-500">
          <span>{courseName} ({assignmentType})</span>
          <span>Due: {formatDate(assignment.dueDate)}</span>
        </div>
      </div>
    </motion.div>
  );
};

export default AssignmentCard;
