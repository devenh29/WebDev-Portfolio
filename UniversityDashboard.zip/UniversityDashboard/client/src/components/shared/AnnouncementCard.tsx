import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { timeAgo } from '@/lib/utils';
import { Announcement, User } from '@shared/schema';

interface AnnouncementCardProps {
  announcement: Announcement;
  creator?: Partial<User>;
  isNew?: boolean;
}

const AnnouncementCard: React.FC<AnnouncementCardProps> = ({ 
  announcement, 
  creator,
  isNew = false 
}) => {
  return (
    <div className={`border-l-4 ${isNew ? 'border-indigo-500' : 'border-slate-300'} pl-4 mb-4`}>
      <div className="flex justify-between items-start">
        <div>
          <h3 className="font-medium text-slate-900">{announcement.title}</h3>
          <p className="text-slate-600 text-sm mt-1">{announcement.content}</p>
        </div>
        {isNew && (
          <Badge variant="warning">New</Badge>
        )}
      </div>
      <div className="text-xs text-slate-500 mt-2">
        Posted by {creator?.firstName ?? 'Admin'} {creator?.lastName ?? ''} • {announcement.createdAt ? timeAgo(announcement.createdAt) : 'Recently'}
      </div>
    </div>
  );
};

export default AnnouncementCard;
