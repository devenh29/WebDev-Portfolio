import React, { useEffect, useRef, useState } from 'react';
import { 
  calculateAttendancePercentage, 
  getAttendanceStatus, 
  getWeeklyAttendance, 
  getMonthlyAttendance 
} from '@/lib/utils';
import { Attendance } from '@shared/schema';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { AlertTriangle, Check, Calendar, TrendingUp, BarChart3 } from 'lucide-react';

interface AttendanceChartProps {
  attendanceRecords: Attendance[];
  courses: any[];
  courseId?: number;
  courseName?: string;
}

type TimeFrame = 'overall' | 'weekly' | 'monthly';

const AttendanceChart: React.FC<AttendanceChartProps> = ({ 
  attendanceRecords, 
  courses, 
  courseId, 
  courseName 
}) => {
  const [activeTimeFrame, setActiveTimeFrame] = useState<TimeFrame>('overall');
  const chartRef = useRef<HTMLCanvasElement>(null);

  // Filter by course if courseId is provided
  const filteredRecords = courseId 
    ? attendanceRecords.filter(record => record.courseId === courseId)
    : attendanceRecords;

  // Calculate attendance statistics
  const presentCount = filteredRecords.filter(record => record.status === 'present').length;
  const totalCount = filteredRecords.length;
  const attendancePercentage = calculateAttendancePercentage(presentCount, totalCount);
  const status = getAttendanceStatus(attendancePercentage);
  
  // Get weekly and monthly attendance
  const weeklyAttendance = getWeeklyAttendance(attendanceRecords, courseId);
  const monthlyAttendance = getMonthlyAttendance(attendanceRecords, courseId);

  // Get current active statistics based on timeframe
  const getActiveStats = () => {
    switch(activeTimeFrame) {
      case 'weekly':
        return weeklyAttendance;
      case 'monthly':
        return monthlyAttendance;
      default:
        return {
          present: presentCount,
          total: totalCount,
          percentage: attendancePercentage,
          status
        };
    }
  };

  const activeStats = getActiveStats();

  // Draw chart
  useEffect(() => {
    if (chartRef.current) {
      const ctx = chartRef.current.getContext('2d');
      if (ctx) {
        // Clear previous chart
        ctx.clearRect(0, 0, chartRef.current.width, chartRef.current.height);
        
        // Draw doughnut chart
        const centerX = chartRef.current.width / 2;
        const centerY = chartRef.current.height / 2;
        const radius = Math.min(centerX, centerY) - 10;
        const innerRadius = radius * 0.75;
        
        // Draw background circle
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
        ctx.fillStyle = '#e2e8f0';
        ctx.fill();
        
        // Get color based on percentage
        let fillColor = '#4ade80'; // Green
        if (activeStats.percentage < 60) {
          fillColor = '#ef4444'; // Red
        } else if (activeStats.percentage < 75) {
          fillColor = '#facc15'; // Yellow
        }
        
        // Draw attendance arc
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.arc(centerX, centerY, radius, -0.5 * Math.PI, (-0.5 + (activeStats.percentage / 100) * 2) * Math.PI);
        ctx.lineTo(centerX, centerY);
        ctx.fillStyle = fillColor;
        ctx.fill();
        
        // Draw inner circle to create doughnut
        ctx.beginPath();
        ctx.arc(centerX, centerY, innerRadius, 0, 2 * Math.PI);
        ctx.fillStyle = 'white';
        ctx.fill();
      }
    }
  }, [activeStats.percentage]);

  // Format timeframe title
  const getTimeframeTitle = () => {
    switch(activeTimeFrame) {
      case 'weekly':
        return 'This Week';
      case 'monthly':
        return 'This Month';
      default:
        return 'Overall';
    }
  };

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="text-lg font-bold text-slate-800 flex items-center">
          <BarChart3 className="mr-2 h-5 w-5 text-indigo-500" />
          Attendance Dashboard
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="overall" onValueChange={(value) => setActiveTimeFrame(value as TimeFrame)}>
          <TabsList className="grid grid-cols-3 mb-6">
            <TabsTrigger value="overall">Overall</TabsTrigger>
            <TabsTrigger value="weekly">Weekly</TabsTrigger>
            <TabsTrigger value="monthly">Monthly</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overall" className="mt-0">
            <div className="flex flex-col md:flex-row gap-6">
              <div className="md:w-1/3 flex flex-col items-center">
                <div className="relative w-36 h-36 mb-3">
                  <canvas ref={chartRef} width="144" height="144" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-3xl font-bold">{activeStats.percentage}%</div>
                      <div className="text-xs text-slate-500">{getTimeframeTitle()}</div>
                    </div>
                  </div>
                </div>
                <div className="flex items-center">
                  <Badge className={activeStats.status.badge}>
                    {activeStats.status.icon} {activeStats.status.status} Standing
                  </Badge>
                </div>
                <div className="mt-3 text-sm text-center">
                  <span className="text-slate-600">Present: </span>
                  <span className="font-medium">{activeStats.present}/{activeStats.total} classes</span>
                </div>
                {activeStats.percentage < 75 && (
                  <div className="mt-3 flex items-center text-red-500 text-sm">
                    <AlertTriangle className="h-4 w-4 mr-1" />
                    <span>Attendance below required threshold</span>
                  </div>
                )}
              </div>
              
              <div className="md:w-2/3">
                <h3 className="text-md font-medium text-slate-700 mb-4">Subject-wise Attendance</h3>
                
                <div className="space-y-4">
                  {courses.map((course) => {
                    const courseAttendance = attendanceRecords.filter((a) => a.courseId === course.id);
                    const present = courseAttendance.filter((a) => a.status === 'present').length;
                    const total = courseAttendance.length;
                    const percentage = calculateAttendancePercentage(present, total);
                    const courseStatus = getAttendanceStatus(percentage);
                    
                    return (
                      <div key={course.id} className="bg-slate-50 p-4 rounded-lg">
                        <div className="flex justify-between items-center mb-2">
                          <div className="flex items-center">
                            <span className="mr-2">{courseStatus.icon}</span>
                            <span className="font-medium">{course.name}</span>
                          </div>
                          <Badge className={courseStatus.badge}>
                            {percentage}%
                          </Badge>
                        </div>
                        <div className="mb-1">
                          <Progress value={percentage} className="h-2" />
                        </div>
                        <div className="flex justify-between text-xs text-slate-500">
                          <span>Present: {present}/{total} classes</span>
                          {percentage < 75 ? (
                            <span className="text-red-500 flex items-center">
                              <AlertTriangle className="h-3 w-3 mr-1" /> 
                              {percentage < 60 ? 'Defaulter Alert' : 'Warning'}
                            </span>
                          ) : (
                            <span className="text-green-500 flex items-center">
                              <Check className="h-3 w-3 mr-1" /> Good Standing
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="weekly" className="mt-0">
            <div className="flex flex-col md:flex-row gap-6">
              <div className="md:w-1/3 flex flex-col items-center">
                <div className="relative w-36 h-36 mb-3">
                  <canvas ref={chartRef} width="144" height="144" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-3xl font-bold">{weeklyAttendance.percentage}%</div>
                      <div className="text-xs text-slate-500">This Week</div>
                    </div>
                  </div>
                </div>
                <div className="flex items-center">
                  <Badge className={weeklyAttendance.status.badge}>
                    {weeklyAttendance.status.icon} {weeklyAttendance.status.status}
                  </Badge>
                </div>
                <div className="mt-3 text-sm text-center">
                  <span className="text-slate-600">Present: </span>
                  <span className="font-medium">{weeklyAttendance.present}/{weeklyAttendance.total} classes</span>
                </div>
                <div className="mt-4 flex items-center text-sm">
                  <Calendar className="h-4 w-4 mr-2 text-indigo-500" />
                  <span>Week of {new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
                </div>
              </div>
              
              <div className="md:w-2/3">
                <h3 className="text-md font-medium text-slate-700 mb-4">Weekly Summary</h3>
                <div className="bg-slate-50 p-4 rounded-lg">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {courses.map((course) => {
                      const weeklyData = getWeeklyAttendance(attendanceRecords, course.id);
                      if (weeklyData.total === 0) return null;
                      
                      return (
                        <div key={course.id} className="border border-slate-200 rounded-md p-3">
                          <div className="flex justify-between items-center mb-2">
                            <span className="font-medium text-sm">{course.name}</span>
                            <Badge className={weeklyData.status.badge}>
                              {weeklyData.percentage}%
                            </Badge>
                          </div>
                          <div className="mb-1">
                            <Progress value={weeklyData.percentage} className="h-2" />
                          </div>
                          <div className="text-xs text-slate-500">
                            {weeklyData.present}/{weeklyData.total} classes this week
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="monthly" className="mt-0">
            <div className="flex flex-col md:flex-row gap-6">
              <div className="md:w-1/3 flex flex-col items-center">
                <div className="relative w-36 h-36 mb-3">
                  <canvas ref={chartRef} width="144" height="144" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-3xl font-bold">{monthlyAttendance.percentage}%</div>
                      <div className="text-xs text-slate-500">This Month</div>
                    </div>
                  </div>
                </div>
                <div className="flex items-center">
                  <Badge className={monthlyAttendance.status.badge}>
                    {monthlyAttendance.status.icon} {monthlyAttendance.status.status}
                  </Badge>
                </div>
                <div className="mt-3 text-sm text-center">
                  <span className="text-slate-600">Present: </span>
                  <span className="font-medium">{monthlyAttendance.present}/{monthlyAttendance.total} classes</span>
                </div>
                <div className="mt-4 flex items-center text-sm">
                  <Calendar className="h-4 w-4 mr-2 text-indigo-500" />
                  <span>{new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</span>
                </div>
              </div>
              
              <div className="md:w-2/3">
                <h3 className="text-md font-medium text-slate-700 mb-4">Monthly Trend</h3>
                <div className="bg-slate-50 p-4 rounded-lg">
                  <div className="mb-4 flex items-center text-sm">
                    <TrendingUp className="h-4 w-4 mr-2 text-green-500" />
                    <span className="font-medium">Monthly Attendance Summary</span>
                  </div>
                  
                  <div className="space-y-4">
                    {courses.map((course) => {
                      const monthlyData = getMonthlyAttendance(attendanceRecords, course.id);
                      if (monthlyData.total === 0) return null;
                      
                      return (
                        <div key={course.id} className="border border-slate-200 rounded-md p-3">
                          <div className="flex justify-between items-center mb-2">
                            <div className="flex items-center">
                              <span className="mr-2">{monthlyData.status.icon}</span>
                              <span className="font-medium text-sm">{course.name}</span>
                            </div>
                            <Badge className={monthlyData.status.badge}>
                              {monthlyData.percentage}%
                            </Badge>
                          </div>
                          <div className="mb-1">
                            <Progress value={monthlyData.percentage} className="h-2" />
                          </div>
                          <div className="flex justify-between text-xs text-slate-500">
                            <span>{monthlyData.present}/{monthlyData.total} classes this month</span>
                            {monthlyData.percentage < 75 ? (
                              <span className="text-red-500 flex items-center">
                                <AlertTriangle className="h-3 w-3 mr-1" /> Attention needed
                              </span>
                            ) : (
                              <span className="text-green-500 flex items-center">
                                <Check className="h-3 w-3 mr-1" /> On track
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default AttendanceChart;
