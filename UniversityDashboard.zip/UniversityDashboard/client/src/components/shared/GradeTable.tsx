import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { getGradeColor } from '@/lib/utils';
import { Grade, Course } from '@shared/schema';

interface GradeTableProps {
  grades: Grade[];
  courses: Course[];
  term: string;
}

const GradeTable: React.FC<GradeTableProps> = ({ grades, courses, term }) => {
  // Filter grades by term
  const filteredGrades = grades.filter(grade => grade.term === term);

  // Helper function to get course name
  const getCourseName = (courseId: number) => {
    const course = courses.find(c => c.id === courseId);
    return course ? course.name : 'Unknown Course';
  };

  // Helper function to get course code
  const getCourseCode = (courseId: number) => {
    const course = courses.find(c => c.id === courseId);
    return course ? course.code : 'N/A';
  };

  return (
    <Table>
      <TableHeader className="bg-slate-50">
        <TableRow>
          <TableHead>Course</TableHead>
          <TableHead>Internal</TableHead>
          <TableHead>Mid-Term</TableHead>
          <TableHead>Assignments</TableHead>
          <TableHead>Final</TableHead>
          <TableHead>Grade</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {filteredGrades.length > 0 ? (
          filteredGrades.map((grade) => (
            <TableRow key={grade.id}>
              <TableCell>
                <div className="text-sm font-medium text-slate-900">{getCourseName(grade.courseId)}</div>
                <div className="text-xs text-slate-500">{getCourseCode(grade.courseId)}</div>
              </TableCell>
              <TableCell className="text-sm text-slate-900">
                {grade.internalMarks !== null ? `${grade.internalMarks}/20` : 'N/A'}
              </TableCell>
              <TableCell className="text-sm text-slate-900">
                {grade.midtermMarks !== null ? `${grade.midtermMarks}/30` : 'N/A'}
              </TableCell>
              <TableCell className="text-sm text-slate-900">
                {grade.assignmentMarks !== null ? `${grade.assignmentMarks}/25` : 'N/A'}
              </TableCell>
              <TableCell className="text-sm text-slate-900">
                {grade.finalMarks !== null ? `${grade.finalMarks}/100` : 'Upcoming'}
              </TableCell>
              <TableCell>
                {grade.grade && (
                  <Badge className={getGradeColor(grade.grade)}>{grade.grade}</Badge>
                )}
              </TableCell>
            </TableRow>
          ))
        ) : (
          <TableRow>
            <TableCell colSpan={6} className="text-center py-4 text-slate-500">
              No grades available for this term
            </TableCell>
          </TableRow>
        )}
      </TableBody>
    </Table>
  );
};

export default GradeTable;
