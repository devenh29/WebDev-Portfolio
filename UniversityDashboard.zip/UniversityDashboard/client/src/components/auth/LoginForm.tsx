import React, { useState } from 'react';
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useLocation } from 'wouter';
import { School, User, Settings } from 'lucide-react';
import { z } from 'zod';
import { motion } from 'framer-motion';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { loginSchema } from '@shared/schema';

const LoginForm: React.FC = () => {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [selectedRole, setSelectedRole] = useState<string | null>(null);

  const form = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
      role: "student"
    }
  });

  const { register, handleSubmit, setValue, formState: { errors, isSubmitting } } = form;

  const onSubmit = async (data: z.infer<typeof loginSchema>) => {
    try {
      if (!selectedRole) {
        toast({
          title: "Error",
          description: "Please select a user type",
          variant: "destructive"
        });
        return;
      }

      data.role = selectedRole as "student" | "faculty" | "admin";
      const response = await apiRequest('POST', '/api/auth/login', data);
      
      if (response.ok) {
        toast({
          title: "Success",
          description: "Logged in successfully",
        });
        setLocation('/dashboard');
      }
    } catch (error) {
      console.error(error);
      toast({
        title: "Error",
        description: "Invalid credentials",
        variant: "destructive"
      });
    }
  };

  const handleRoleSelect = (role: string) => {
    setSelectedRole(role);
    setValue('role', role as "student" | "faculty" | "admin");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-600 to-blue-600 px-4">
      <Card className="max-w-md w-full bg-white rounded-xl shadow-2xl overflow-hidden">
        <CardContent className="p-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-slate-800 font-heading">University <span className="text-indigo-600">Management</span></h1>
            <p className="text-slate-500 mt-2">Sign in to access your dashboard</p>
          </div>
          
          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="mb-4">
              <label className="block text-sm font-medium text-slate-700 mb-1" htmlFor="username">
                Username
              </label>
              <Input
                id="username"
                placeholder="Enter your username"
                {...register("username")}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              />
              {errors.username && (
                <p className="text-sm text-red-500 mt-1">{errors.username.message}</p>
              )}
            </div>
            
            <div className="mb-6">
              <label className="block text-sm font-medium text-slate-700 mb-1" htmlFor="password">
                Password
              </label>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                {...register("password")}
                className="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              />
              {errors.password && (
                <p className="text-sm text-red-500 mt-1">{errors.password.message}</p>
              )}
              <div className="flex justify-end mt-1">
                <a href="#" className="text-xs text-indigo-600 hover:text-indigo-800">Forgot password?</a>
              </div>
            </div>
            
            <div className="mb-6">
              <label className="block text-sm font-medium text-slate-700 mb-2">Select User Type</label>
              <div className="grid grid-cols-3 gap-3">
                <motion.button
                  type="button"
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => handleRoleSelect("student")}
                  className={`bg-white border-2 ${
                    selectedRole === "student" ? "border-indigo-500 bg-indigo-50" : "border-slate-200"
                  } rounded-lg p-4 text-center hover:border-indigo-500 transition-all cursor-pointer group`}
                >
                  <School className={`mx-auto mb-2 ${
                    selectedRole === "student" ? "text-indigo-500" : "text-slate-400"
                  } group-hover:text-indigo-500`} />
                  <span className="block text-sm font-medium text-slate-700">Student</span>
                </motion.button>
                
                <motion.button
                  type="button"
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => handleRoleSelect("faculty")}
                  className={`bg-white border-2 ${
                    selectedRole === "faculty" ? "border-indigo-500 bg-indigo-50" : "border-slate-200"
                  } rounded-lg p-4 text-center hover:border-indigo-500 transition-all cursor-pointer group`}
                >
                  <User className={`mx-auto mb-2 ${
                    selectedRole === "faculty" ? "text-indigo-500" : "text-slate-400"
                  } group-hover:text-indigo-500`} />
                  <span className="block text-sm font-medium text-slate-700">Faculty</span>
                </motion.button>
                
                <motion.button
                  type="button"
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => handleRoleSelect("admin")}
                  className={`bg-white border-2 ${
                    selectedRole === "admin" ? "border-indigo-500 bg-indigo-50" : "border-slate-200"
                  } rounded-lg p-4 text-center hover:border-indigo-500 transition-all cursor-pointer group`}
                >
                  <Settings className={`mx-auto mb-2 ${
                    selectedRole === "admin" ? "text-indigo-500" : "text-slate-400"
                  } group-hover:text-indigo-500`} />
                  <span className="block text-sm font-medium text-slate-700">Admin</span>
                </motion.button>
              </div>
              {errors.role && (
                <p className="text-sm text-red-500 mt-1">{errors.role.message}</p>
              )}
            </div>
            
            <Button
              type="submit"
              className="w-full bg-indigo-600 text-white py-2.5 rounded-md font-medium hover:bg-indigo-700 transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 mb-4"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Signing In..." : "Sign In"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default LoginForm;
