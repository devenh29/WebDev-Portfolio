import { pgTable, text, serial, integer, boolean, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Roles enum
export const roleEnum = pgEnum('role', ['student', 'faculty', 'admin']);

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("firstName").notNull(),
  lastName: text("lastName").notNull(),
  email: text("email").notNull(),
  role: roleEnum("role").notNull(),
  department: text("department"),
  program: text("program"),
  semester: integer("semester"),
  profileImage: text("profileImage").default("/default-profile.jpg"),
});

// Courses table
export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  description: text("description"),
  department: text("department").notNull(),
  credits: integer("credits").notNull(),
  type: text("type").notNull(), // theory or lab
});

// Assignments table
export const assignments = pgTable("assignments", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  courseId: integer("courseId").notNull(),
  dueDate: timestamp("dueDate").notNull(),
  maxMarks: integer("maxMarks").notNull(),
  assignmentType: text("assignmentType").notNull(), // theory or lab
  createdBy: integer("createdBy").notNull(), // faculty id
  isChecked: boolean("isChecked"),
  submitted: boolean("submitted").default(false),
  graded: boolean("graded").default(false),
  grade: integer("grade"),
  feedback: text("feedback"),
});

// Student Assignments table
export const studentAssignments = pgTable("student_assignments", {
  id: serial("id").primaryKey(),
  studentId: integer("studentId").notNull(),
  assignmentId: integer("assignmentId").notNull(),
  submissionDate: timestamp("submissionDate"),
  fileUrl: text("fileUrl"),
  marks: integer("marks"),
  feedback: text("feedback"),
  status: text("status").default("pending"), // pending, submitted, graded
});

// Announcements table
export const announcements = pgTable("announcements", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  createdBy: integer("createdBy").notNull(),
  department: text("department"),
  createdAt: timestamp("createdAt").defaultNow(),
});

// Attendance table
export const attendance = pgTable("attendance", {
  id: serial("id").primaryKey(),
  studentId: integer("studentId").notNull(),
  courseId: integer("courseId").notNull(),
  date: timestamp("date").defaultNow(),
  status: text("status").default("absent"), // present, absent, late, excused
  notes: text("notes"),
});

// Grades table
export const grades = pgTable("grades", {
  id: serial("id").primaryKey(),
  studentId: integer("studentId").notNull(),
  courseId: integer("courseId").notNull(),
  internalMarks: integer("internalMarks"),
  midtermMarks: integer("midtermMarks"),
  assignmentMarks: integer("assignmentMarks"),
  finalMarks: integer("finalMarks"),
  totalMarks: integer("totalMarks"),
  grade: text("grade"),
  term: text("term").notNull(), // Fall 2023, Spring 2024, etc.
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users);
export const insertCourseSchema = createInsertSchema(courses);
export const insertAssignmentSchema = createInsertSchema(assignments);
export const insertStudentAssignmentSchema = createInsertSchema(studentAssignments);
export const insertAnnouncementSchema = createInsertSchema(announcements);
export const insertAttendanceSchema = createInsertSchema(attendance);
export const insertGradeSchema = createInsertSchema(grades);

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Course = typeof courses.$inferSelect;
export type InsertCourse = z.infer<typeof insertCourseSchema>;

export type Assignment = typeof assignments.$inferSelect;
export type InsertAssignment = z.infer<typeof insertAssignmentSchema>;

export type StudentAssignment = typeof studentAssignments.$inferSelect;
export type InsertStudentAssignment = z.infer<typeof insertStudentAssignmentSchema>;

export type Announcement = typeof announcements.$inferSelect;
export type InsertAnnouncement = z.infer<typeof insertAnnouncementSchema>;

export type Attendance = typeof attendance.$inferSelect;
export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;

export type Grade = typeof grades.$inferSelect;
export type InsertGrade = z.infer<typeof insertGradeSchema>;

// Authentication type
export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
  role: z.enum(["student", "faculty", "admin"])
});

export type LoginCredentials = z.infer<typeof loginSchema>;
